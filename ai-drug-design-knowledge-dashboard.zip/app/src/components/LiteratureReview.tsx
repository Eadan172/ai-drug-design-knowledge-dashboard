import { useState, useRef, useEffect } from 'react';
import { BookOpen, ExternalLink, Calendar, TrendingUp, ChevronLeft, ChevronRight, Database } from 'lucide-react';
import type { Paper, SortOption } from '@/types';

interface LiteratureReviewProps {
  papers: Paper[];
  sectionName: string;
}

const sourceColors: Record<string, string> = {
  'PubMed': 'text-cyan-400 bg-cyan-500/10',
  'arXiv': 'text-purple-400 bg-purple-500/10',
  'Google Scholar': 'text-green-400 bg-green-500/10',
};

export default function LiteratureReview({ papers, sectionName }: LiteratureReviewProps) {
  const [sortBy, setSortBy] = useState<SortOption>('impact');
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  // Sort papers: first by IF (desc), then by citations (desc)
  const sortedPapers = [...papers].sort((a, b) => {
    if (sortBy === 'impact') {
      const ifDiff = (b.impactFactor || 0) - (a.impactFactor || 0);
      if (ifDiff !== 0) return ifDiff;
      return b.citations - a.citations;
    }
    return (b.publishDate || '').localeCompare(a.publishDate || '');
  });

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  useEffect(() => {
    checkScroll();
    const el = scrollRef.current;
    if (el) {
      el.addEventListener('scroll', checkScroll);
      return () => el.removeEventListener('scroll', checkScroll);
    }
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 400;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section className="py-12">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-500/20 flex items-center justify-center border border-cyan-500/30">
              <BookOpen className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">文献综述</h2>
              <p className="text-slate-400 text-sm">{sectionName}领域核心文献精选（按IF、引用量优先）</p>
            </div>
          </div>

          {/* Sort Options */}
          <div className="flex items-center gap-2 bg-slate-800/50 rounded-lg p-1 border border-slate-700/50">
            <button
              onClick={() => setSortBy('impact')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                sortBy === 'impact'
                  ? 'bg-cyan-500/20 text-cyan-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              按IF/引用
            </button>
            <button
              onClick={() => setSortBy('date')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                sortBy === 'date'
                  ? 'bg-cyan-500/20 text-cyan-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Calendar className="w-4 h-4" />
              按日期
            </button>
          </div>
        </div>

        {/* Scrollable Papers */}
        <div className="relative">
          {/* Scroll Buttons */}
          {canScrollLeft && (
            <button
              onClick={() => scroll('left')}
              className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-slate-800/90 border border-slate-700 flex items-center justify-center text-white shadow-lg hover:bg-slate-700 transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}
          {canScrollRight && (
            <button
              onClick={() => scroll('right')}
              className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-slate-800/90 border border-slate-700 flex items-center justify-center text-white shadow-lg hover:bg-slate-700 transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          )}

          {/* Papers Container */}
          <div
            ref={scrollRef}
            className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide scroll-smooth"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {sortedPapers.map((paper, index) => (
              <div
                key={paper.id}
                className="flex-shrink-0 w-[350px] group"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="h-full p-5 rounded-xl bg-slate-800/40 border border-slate-700/50 hover:border-cyan-500/30 hover:bg-slate-800/60 transition-all duration-300 hover:-translate-y-1">
                  {/* Title */}
                  <h3 className="text-white font-semibold text-sm leading-relaxed mb-3 line-clamp-2 group-hover:text-cyan-400 transition-colors">
                    {paper.title}
                  </h3>

                  {/* Meta Info */}
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 text-xs font-medium">
                      {paper.year}
                    </span>
                    {paper.impactFactor && (
                      <span className="px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400 text-xs font-medium">
                        IF: {paper.impactFactor}
                      </span>
                    )}
                    <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 text-xs">
                      被引: {paper.citations}
                    </span>
                  </div>

                  {/* Source Badge */}
                  {paper.source && (
                    <div className="flex items-center gap-1 mb-2">
                      <Database className="w-3 h-3 text-slate-500" />
                      <span className={`px-2 py-0.5 rounded-full text-xs ${sourceColors[paper.source] || 'text-slate-400 bg-slate-700/50'}`}>
                        {paper.source}
                      </span>
                    </div>
                  )}

                  {/* Journal & Authors */}
                  <p className="text-slate-400 text-xs mb-2 line-clamp-1">
                    {paper.journal}
                  </p>
                  <p className="text-slate-500 text-xs mb-4 line-clamp-1">
                    {paper.authors}
                  </p>

                  {/* Abstract */}
                  <p className="text-slate-400 text-xs leading-relaxed mb-4 line-clamp-3">
                    {paper.abstract}
                  </p>

                  {/* Link */}
                  <a
                    href={paper.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-cyan-400 text-xs font-medium hover:text-cyan-300 transition-colors"
                  >
                    查看全文
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </section>
  );
}
