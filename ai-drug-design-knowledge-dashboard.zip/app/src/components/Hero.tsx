import { useEffect, useRef, useState } from 'react';
import { Clock, Sparkles, Database, RefreshCw, ExternalLink } from 'lucide-react';

interface HeroProps {
  onUpdate?: () => void;
  isUpdating?: boolean;
}

export default function Hero({ onUpdate, isUpdating = false }: HeroProps) {
  const heroRef = useRef<HTMLDivElement>(null);
  const [lastUpdate, setLastUpdate] = useState<string>('2025-02-19 00:00');

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = heroRef.current?.querySelectorAll('.animate-on-scroll');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const handleUpdate = () => {
    if (onUpdate && !isUpdating) {
      onUpdate();
      setLastUpdate(new Date().toLocaleString('zh-CN'));
    }
  };

  return (
    <section
      ref={heroRef}
      className="relative min-h-[50vh] flex items-center justify-center pt-24 pb-12 overflow-hidden"
    >
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: 'url(/hero-bg.jpg)' }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a1628]/60 via-[#0a1628]/40 to-[#0a1628]" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 ease-out">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-6">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span className="text-cyan-400 text-sm font-medium">
              AI驱动药物研发知识平台
            </span>
          </div>
        </div>

        <h1 className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 ease-out delay-100 text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
          AI药物设计
          <span className="block mt-2 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
            知识看板
          </span>
        </h1>

        <p className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 ease-out delay-200 text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto mb-8">
          汇聚全球前沿文献、技术知识与产业动态
          <br />
          <span className="text-slate-400 text-base">
            涵盖化学小分子、多肽、RNA/抗体、PROTAC、天然产物、虚拟细胞七大领域
          </span>
        </p>

        <div className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 ease-out delay-300 flex flex-wrap justify-center gap-4 mb-6">
          <a 
            href="https://pubmed.ncbi.nlm.nih.gov/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800/50 border border-slate-700/50 hover:border-cyan-500/30 transition-colors"
          >
            <Database className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-300 text-sm">PubMed</span>
            <ExternalLink className="w-3 h-3 text-slate-500" />
          </a>
          <a 
            href="https://arxiv.org/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800/50 border border-slate-700/50 hover:border-purple-500/30 transition-colors"
          >
            <Database className="w-4 h-4 text-purple-400" />
            <span className="text-slate-300 text-sm">arXiv</span>
            <ExternalLink className="w-3 h-3 text-slate-500" />
          </a>
          <a 
            href="https://scholar.google.com/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800/50 border border-slate-700/50 hover:border-green-500/30 transition-colors"
          >
            <Database className="w-4 h-4 text-green-400" />
            <span className="text-slate-300 text-sm">Google Scholar</span>
            <ExternalLink className="w-3 h-3 text-slate-500" />
          </a>
        </div>

        {/* Update Button */}
        <div className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 ease-out delay-400">
          <button
            onClick={handleUpdate}
            disabled={isUpdating}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium hover:from-cyan-400 hover:to-blue-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isUpdating ? (
              <RefreshCw className="w-5 h-5 animate-spin" />
            ) : (
              <Clock className="w-5 h-5" />
            )}
            {isUpdating ? '更新中...' : '每日更新'}
          </button>
          <p className="mt-2 text-slate-500 text-sm">
            上次更新: {lastUpdate}
          </p>
          <p className="text-slate-600 text-xs">
            更新IF、引用量、资源链接有效性
          </p>
        </div>
      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#0a1628] to-transparent" />

      <style>{`
        .animate-in {
          opacity: 1 !important;
          transform: translateY(0) !important;
        }
      `}</style>
    </section>
  );
}
