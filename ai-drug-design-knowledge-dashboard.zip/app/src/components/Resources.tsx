import { useState } from 'react';
import { GraduationCap, BookOpen, Video, FileText, ExternalLink, DollarSign, ShoppingCart } from 'lucide-react';
import type { Resource } from '@/types';

interface ResourcesProps {
  resources: Resource[];
  sectionName: string;
}

type ResourceType = 'all' | 'book' | 'course' | 'blog';

const typeConfig: Record<string, { icon: React.ElementType; label: string; color: string }> = {
  book: { icon: BookOpen, label: '教材', color: 'text-amber-400' },
  course: { icon: Video, label: '课程', color: 'text-green-400' },
  blog: { icon: FileText, label: '博客', color: 'text-blue-400' },
  video: { icon: Video, label: '视频', color: 'text-pink-400' },
};

export default function Resources({ resources, sectionName }: ResourcesProps) {
  const [filter, setFilter] = useState<ResourceType>('all');
  const [expandedBook, setExpandedBook] = useState<string | null>(null);

  const books = resources.filter((r) => r.type === 'book');
  const courses = resources.filter((r) => r.type === 'course');
  const blogs = resources.filter((r) => r.type === 'blog' || r.type === 'video');

  return (
    <section className="py-12">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-green-500/20 to-emerald-500/20 flex items-center justify-center border border-green-500/30">
              <GraduationCap className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">技术学科知识</h2>
              <p className="text-slate-400 text-sm">{sectionName}精选学习资源</p>
            </div>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-2 bg-slate-800/50 rounded-lg p-1 border border-slate-700/50">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                filter === 'all'
                  ? 'bg-green-500/20 text-green-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              全部
            </button>
            <button
              onClick={() => setFilter('book')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                filter === 'book'
                  ? 'bg-amber-500/20 text-amber-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              教材
            </button>
            <button
              onClick={() => setFilter('course')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                filter === 'course'
                  ? 'bg-green-500/20 text-green-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              课程
            </button>
            <button
              onClick={() => setFilter('blog')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                filter === 'blog'
                  ? 'bg-blue-500/20 text-blue-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              博客/视频
            </button>
          </div>
        </div>

        {/* Resources Grid */}
        {(filter === 'all' || filter === 'book') && books.length > 0 && (
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-amber-400" />
              经典教材
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {books.map((resource) => (
                <BookCard 
                  key={resource.id} 
                  resource={resource} 
                  isExpanded={expandedBook === resource.id}
                  onToggle={() => setExpandedBook(expandedBook === resource.id ? null : resource.id)}
                />
              ))}
            </div>
          </div>
        )}

        {(filter === 'all' || filter === 'course') && courses.length > 0 && (
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Video className="w-5 h-5 text-green-400" />
              在线课程
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {courses.map((resource) => (
                <ResourceCard key={resource.id} resource={resource} />
              ))}
            </div>
          </div>
        )}

        {(filter === 'all' || filter === 'blog') && blogs.length > 0 && (
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-400" />
              技术博客/视频
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {blogs.map((resource) => (
                <ResourceCard key={resource.id} resource={resource} />
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function BookCard({ resource, isExpanded, onToggle }: { resource: Resource; isExpanded: boolean; onToggle: () => void }) {
  return (
    <div className="group p-5 rounded-xl bg-slate-800/40 border border-slate-700/50 hover:border-amber-500/30 hover:bg-slate-800/60 transition-all duration-300">
      <div className="flex items-start justify-between mb-3">
        <div className="w-10 h-10 rounded-lg bg-slate-700/50 flex items-center justify-center text-amber-400">
          <BookOpen className="w-5 h-5" />
        </div>
        <div className="flex items-center gap-2">
          <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 text-xs font-medium">
            教材
          </span>
        </div>
      </div>

      <h4 className="text-white font-semibold text-sm mb-2 group-hover:text-amber-400 transition-colors line-clamp-2">
        {resource.title}
      </h4>

      {resource.author && (
        <p className="text-slate-500 text-xs mb-2">
          作者: {resource.author}
        </p>
      )}

      <p className="text-slate-400 text-xs leading-relaxed mb-3 line-clamp-2">
        {resource.description}
      </p>

      {/* Purchase Links */}
      {resource.purchaseLinks && resource.purchaseLinks.length > 0 && (
        <div className="mt-3">
          <button
            onClick={onToggle}
            className="flex items-center gap-2 text-amber-400 text-xs font-medium hover:text-amber-300 transition-colors"
          >
            <ShoppingCart className="w-4 h-4" />
            {isExpanded ? '收起购买链接' : '查看购买渠道'}
          </button>
          
          {isExpanded && (
            <div className="mt-3 space-y-2">
              {resource.purchaseLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-2 rounded-lg bg-slate-700/30 hover:bg-slate-700/50 transition-colors"
                >
                  <span className="text-slate-300 text-xs">{link.platform}</span>
                  <span className="text-amber-400 text-xs font-medium">{link.price}</span>
                </a>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="flex items-center justify-between mt-3">
        <span className="text-slate-500 text-xs">{resource.platform}</span>
        <a 
          href={resource.url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-slate-500 hover:text-amber-400 transition-colors"
        >
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>
    </div>
  );
}

function ResourceCard({ resource }: { resource: Resource }) {
  const config = typeConfig[resource.type] || typeConfig.blog;
  const Icon = config.icon;

  return (
    <a
      href={resource.url}
      target="_blank"
      rel="noopener noreferrer"
      className="group block p-5 rounded-xl bg-slate-800/40 border border-slate-700/50 hover:border-cyan-500/30 hover:bg-slate-800/60 transition-all duration-300 hover:-translate-y-1"
    >
      <div className="flex items-start justify-between mb-3">
        <div className={`w-10 h-10 rounded-lg bg-slate-700/50 flex items-center justify-center ${config.color}`}>
          <Icon className="w-5 h-5" />
        </div>
        <div className="flex items-center gap-2">
          {resource.isFree ? (
            <span className="px-2 py-0.5 rounded-full bg-green-500/10 text-green-400 text-xs font-medium">
              免费
            </span>
          ) : (
            <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 text-xs font-medium flex items-center gap-1">
              <DollarSign className="w-3 h-3" />
              {resource.price || '付费'}
            </span>
          )}
        </div>
      </div>

      <h4 className="text-white font-semibold text-sm mb-2 group-hover:text-cyan-400 transition-colors line-clamp-2">
        {resource.title}
      </h4>

      {resource.author && (
        <p className="text-slate-500 text-xs mb-2">
          作者: {resource.author}
        </p>
      )}

      <p className="text-slate-400 text-xs leading-relaxed mb-3 line-clamp-2">
        {resource.description}
      </p>

      {/* Stats for videos */}
      {(resource.views || resource.likes) && (
        <div className="flex items-center gap-3 mb-3 text-xs text-slate-500">
          {resource.views && <span>播放: {resource.views}</span>}
          {resource.likes && <span>收藏: {resource.likes}</span>}
        </div>
      )}

      {/* Rating */}
      {resource.rating && (
        <div className="flex items-center gap-1 mb-3">
          <span className="text-yellow-400 text-xs">★</span>
          <span className="text-slate-400 text-xs">{resource.rating}</span>
        </div>
      )}

      <div className="flex items-center justify-between">
        <span className="text-slate-500 text-xs">{resource.platform}</span>
        <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 transition-colors" />
      </div>
    </a>
  );
}
