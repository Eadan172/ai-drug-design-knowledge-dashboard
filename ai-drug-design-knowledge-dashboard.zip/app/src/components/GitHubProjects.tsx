import { Github, Star, GitFork, Code, ExternalLink } from 'lucide-react';
import type { GitHubProject } from '@/types';

interface GitHubProjectsProps {
  projects: GitHubProject[];
  sectionName: string;
}

export default function GitHubProjects({ projects, sectionName }: GitHubProjectsProps) {
  if (projects.length === 0) return null;

  return (
    <section className="py-12">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-slate-500/20 to-gray-500/20 flex items-center justify-center border border-slate-500/30">
            <Github className="w-5 h-5 text-slate-400" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">GitHub高分项目</h2>
            <p className="text-slate-400 text-sm">{sectionName}开源工具与代码库</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {projects.map((project) => (
            <a
              key={project.id}
              href={project.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group p-5 rounded-xl bg-slate-800/40 border border-slate-700/50 hover:border-slate-500/30 hover:bg-slate-800/60 transition-all duration-300 hover:-translate-y-1"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Github className="w-5 h-5 text-slate-400" />
                  <h4 className="text-white font-semibold text-sm group-hover:text-slate-300 transition-colors line-clamp-1">
                    {project.name}
                  </h4>
                </div>
                <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-slate-300 transition-colors" />
              </div>

              <p className="text-slate-400 text-xs leading-relaxed mb-4 line-clamp-2">
                {project.description}
              </p>

              <div className="flex items-center gap-4 text-xs text-slate-500 mb-4">
                <span className="flex items-center gap-1">
                  <Star className="w-3 h-3 text-yellow-400" />
                  {project.stars}
                </span>
                <span className="flex items-center gap-1">
                  <GitFork className="w-3 h-3 text-slate-400" />
                  {project.forks}
                </span>
                <span className="flex items-center gap-1">
                  <Code className="w-3 h-3 text-blue-400" />
                  {project.language}
                </span>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {project.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="px-2 py-0.5 rounded-full bg-slate-700/50 text-slate-400 text-xs"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
