import { useState } from 'react';
import { Building2, ExternalLink, Globe, MapPin } from 'lucide-react';
import type { Company } from '@/types';

interface CompaniesProps {
  companies: Company[];
  sectionName: string;
}

type LocationFilter = 'all' | 'domestic' | 'international';

export default function Companies({ companies, sectionName }: CompaniesProps) {
  const [locationFilter, setLocationFilter] = useState<LocationFilter>('all');

  const filteredCompanies = companies.filter((c) => {
    if (locationFilter === 'all') return true;
    return c.location === locationFilter;
  });

  const domesticCompanies = filteredCompanies.filter((c) => c.location === 'domestic');
  const internationalCompanies = filteredCompanies.filter((c) => c.location === 'international');

  return (
    <section className="py-12">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-orange-500/20 to-red-500/20 flex items-center justify-center border border-orange-500/30">
              <Building2 className="w-5 h-5 text-orange-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">研发公司</h2>
              <p className="text-slate-400 text-sm">{sectionName}国内外AI药物设计领军企业</p>
            </div>
          </div>

          {/* Filter */}
          <div className="flex items-center gap-2 bg-slate-800/50 rounded-lg p-1 border border-slate-700/50">
            <button
              onClick={() => setLocationFilter('all')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                locationFilter === 'all'
                  ? 'bg-orange-500/20 text-orange-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              全部
            </button>
            <button
              onClick={() => setLocationFilter('domestic')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                locationFilter === 'domestic'
                  ? 'bg-red-500/20 text-red-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              国内
            </button>
            <button
              onClick={() => setLocationFilter('international')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                locationFilter === 'international'
                  ? 'bg-blue-500/20 text-blue-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              国际
            </button>
          </div>
        </div>

        {/* Companies Grid */}
        {(locationFilter === 'all' || locationFilter === 'international') && internationalCompanies.length > 0 && (
          <div className="mb-10">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Globe className="w-5 h-5 text-blue-400" />
              国际公司
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {internationalCompanies.map((company) => (
                <CompanyCard key={company.id} company={company} />
              ))}
            </div>
          </div>
        )}

        {(locationFilter === 'all' || locationFilter === 'domestic') && domesticCompanies.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-red-400" />
              国内公司
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {domesticCompanies.map((company) => (
                <CompanyCard key={company.id} company={company} />
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function CompanyCard({ company }: { company: Company }) {
  const isDomestic = company.location === 'domestic';

  return (
    <a
      href={company.website}
      target="_blank"
      rel="noopener noreferrer"
      className="group block p-5 rounded-xl bg-slate-800/40 border border-slate-700/50 hover:border-orange-500/30 hover:bg-slate-800/60 transition-all duration-300 hover:-translate-y-1"
    >
      <div className="flex items-start justify-between mb-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-lg font-bold ${
          isDomestic 
            ? 'bg-red-500/10 text-red-400' 
            : 'bg-blue-500/10 text-blue-400'
        }`}>
          {company.name.charAt(0)}
        </div>
        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
          isDomestic
            ? 'bg-red-500/10 text-red-400'
            : 'bg-blue-500/10 text-blue-400'
        }`}>
          {isDomestic ? '国内' : '国际'}
        </span>
      </div>

      <h4 className="text-white font-semibold text-sm mb-1 group-hover:text-orange-400 transition-colors">
        {company.nameCN || company.name}
      </h4>

      <p className="text-slate-500 text-xs mb-3">
        {company.name}
      </p>

      <p className="text-slate-400 text-xs leading-relaxed mb-4 line-clamp-2">
        {company.description}
      </p>

      {/* Tags */}
      <div className="flex flex-wrap gap-1.5 mb-3">
        {company.tags.slice(0, 3).map((tag, index) => (
          <span
            key={index}
            className="px-2 py-0.5 rounded-full bg-slate-700/50 text-slate-400 text-xs"
          >
            {tag}
          </span>
        ))}
      </div>

      <div className="flex items-center justify-between">
        <span className="text-slate-500 text-xs flex items-center gap-1">
          <Globe className="w-3 h-3" />
          官网
        </span>
        <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-orange-400 transition-colors" />
      </div>
    </a>
  );
}
