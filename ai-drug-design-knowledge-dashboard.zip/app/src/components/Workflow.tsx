import { useState } from 'react';
import { Workflow, ChevronDown, ChevronUp } from 'lucide-react';

interface WorkflowProps {
  image: string;
  sectionName: string;
}

const workflowDescriptions: Record<string, { stage: string; description: string }[]> = {
  'small-molecule': [
    { stage: '靶点识别', description: '通过基因组学、蛋白质组学等方法确定疾病相关靶点蛋白' },
    { stage: '苗头发现', description: '利用虚拟筛选、高通量筛选等方法发现初始活性化合物' },
    { stage: '先导优化', description: '通过SAR分析优化化合物活性、选择性、成药性' },
    { stage: '临床前研究', description: '进行ADMET、药效学、毒理学等研究' },
    { stage: '临床试验', description: 'I/II/III期临床试验验证安全性和有效性' },
    { stage: '药物上市', description: '获得监管机构批准，进入市场销售' },
  ],
  'peptide': [
    { stage: '肽链设计', description: '基于靶点结构设计氨基酸序列' },
    { stage: '序列优化', description: '优化肽链长度、氨基酸组成和修饰' },
    { stage: '结构预测', description: '使用AI预测肽链三维结构' },
    { stage: '结合亲和力', description: '评估肽与靶点的结合强度' },
    { stage: '稳定性测试', description: '评估肽的体内外稳定性和半衰期' },
    { stage: '临床开发', description: '进行临床前和临床研究' },
  ],
  'rna-antibody': [
    { stage: '抗原选择', description: '确定疾病相关抗原靶点' },
    { stage: '抗体发现', description: '通过噬菌体展示、单B细胞筛选等方法获得抗体' },
    { stage: '人源化', description: '降低免疫原性，提高临床适用性' },
    { stage: '亲和力成熟', description: '优化抗体与抗原的结合亲和力' },
    { stage: '细胞系开发', description: '建立稳定的高表达细胞系' },
    { stage: '规模化生产', description: 'GMP条件下大规模生产抗体药物' },
  ],
  'protac': [
    { stage: '靶点选择', description: '选择适合降解的靶点蛋白' },
    { stage: '弹头设计', description: '设计结合靶蛋白的配体' },
    { stage: 'Linker优化', description: '优化连接Linker的长度和化学性质' },
    { stage: 'E3连接酶招募', description: '选择并优化E3连接酶配体' },
    { stage: '三元复合物形成', description: '验证靶蛋白-PROTAC-E3三元复合物' },
    { stage: '降解验证', description: '验证靶蛋白的有效降解' },
  ],
  'natural-product': [
    { stage: '来源收集', description: '从植物、微生物、海洋生物等收集样品' },
    { stage: '提取分离', description: '提取活性成分并进行分离纯化' },
    { stage: '结构鉴定', description: '使用NMR、MS等技术确定化合物结构' },
    { stage: '活性筛选', description: '评估化合物的生物活性' },
    { stage: '半合成修饰', description: '对天然产物进行结构修饰' },
    { stage: '衍生物优化', description: '优化衍生物的活性和成药性' },
  ],
  'virtual-cell': [
    { stage: '多组学数据整合', description: '整合基因组、转录组、蛋白质组等数据' },
    { stage: 'AI模型训练', description: '训练深度学习模型学习细胞行为' },
    { stage: '细胞行为预测', description: '预测细胞对各种刺激的反应' },
    { stage: '计算机模拟实验', description: '在虚拟环境中进行药物筛选' },
    { stage: '真实数据验证', description: '与实验数据对比验证模型准确性' },
    { stage: '药物反应预测', description: '预测药物对细胞的影响' },
  ],
};

export default function WorkflowSection({ image, sectionName }: WorkflowProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const sectionId = sectionName.toLowerCase().replace(/[^a-z]/g, '-');
  const stages = workflowDescriptions[sectionId] || workflowDescriptions['small-molecule'];

  return (
    <section className="py-12">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center border border-blue-500/30">
            <Workflow className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">药物研发流程</h2>
            <p className="text-slate-400 text-sm">{sectionName}研发全流程示意</p>
          </div>
        </div>

        {/* Workflow Image */}
        <div className="relative rounded-2xl overflow-hidden mb-6">
          <img 
            src={image} 
            alt={`${sectionName}研发流程`}
            className="w-full h-auto object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a1628] via-transparent to-transparent" />
        </div>

        {/* Expandable Details */}
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-slate-800/50 border border-slate-700/50 text-slate-300 hover:text-white hover:bg-slate-800/70 transition-all"
        >
          {isExpanded ? (
            <>
              <ChevronUp className="w-5 h-5" />
              收起详细说明
            </>
          ) : (
            <>
              <ChevronDown className="w-5 h-5" />
              查看详细说明
            </>
          )}
        </button>

        {isExpanded && (
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 animate-fadeIn">
            {stages.map((stage, index) => (
              <div 
                key={index}
                className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/50"
              >
                <div className="flex items-center gap-3 mb-2">
                  <span className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500/20 to-blue-500/20 flex items-center justify-center text-cyan-400 text-sm font-bold">
                    {index + 1}
                  </span>
                  <h4 className="text-white font-semibold">{stage.stage}</h4>
                </div>
                <p className="text-slate-400 text-sm pl-11">{stage.description}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
      `}</style>
    </section>
  );
}
