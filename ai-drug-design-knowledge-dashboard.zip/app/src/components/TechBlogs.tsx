import { ExternalLink } from 'lucide-react';
import type { TechBlog } from '@/types';
import { Card, CardContent } from '@/components/ui/card';

interface TechBlogsProps {
  blogs: TechBlog[];
  sectionName: string;
}

export default function TechBlogs({ blogs, sectionName }: TechBlogsProps) {
  if (blogs.length === 0) {
    return null;
  }

  return (
    <section id="techblogs" className="py-16 scroll-mt-20">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-10">
          <h2 className="text-3xl font-bold text-white mb-2">
            技术博客
          </h2>
          <p className="text-slate-400">
            {sectionName}领域的技术博客与资讯资源
          </p>
        </div>

        {/* Tech Blogs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogs.map((blog) => (
            <Card
              key={blog.id}
              className="group bg-slate-900/50 border-slate-800 hover:border-cyan-500/50 transition-all duration-300"
            >
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-500/20 flex items-center justify-center">
                      <span className="text-lg font-bold text-cyan-400">
                        {blog.name.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-white group-hover:text-cyan-400 transition-colors">
                        {blog.name}
                      </h3>
                      <span className="text-xs text-slate-500">
                        {blog.platform}
                      </span>
                    </div>
                  </div>
                </div>

                <p className="text-sm text-slate-400 mb-4 line-clamp-2">
                  {blog.description}
                </p>

                <a
                  href={blog.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm text-cyan-400 hover:text-cyan-300 transition-colors"
                >
                  访问博客
                  <ExternalLink className="w-4 h-4" />
                </a>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
