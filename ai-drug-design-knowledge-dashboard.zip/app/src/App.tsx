import { useState, useCallback } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import LiteratureReview from '@/components/LiteratureReview';
import LatestPapers from '@/components/LatestPapers';
import Resources from '@/components/Resources';
import Companies from '@/components/Companies';
import Workflow from '@/components/Workflow';
import TechBlogs from '@/components/TechBlogs';
import GitHubProjects from '@/components/GitHubProjects';
import Footer from '@/components/Footer';
import { allSections, companies } from '@/data/drugDesignData';

function App() {
  const [activeSection, setActiveSection] = useState(allSections[0].id);
  const [isUpdating, setIsUpdating] = useState(false);

  const currentSection = allSections.find((s) => s.id === activeSection);

  // Get companies relevant to current section
  const getRelevantCompanies = () => {
    if (!currentSection) return companies;
    
    switch (currentSection.id) {
      case 'small-molecule':
        return companies.filter(c => c.category === 'small-molecule');
      case 'peptide':
        return companies.filter(c => c.category === 'peptide');
      case 'rna':
        return companies.filter(c => c.category === 'rna');
      case 'antibody':
        return companies.filter(c => c.category === 'antibody');
      case 'protac':
        return companies.filter(c => c.category === 'protac');
      case 'natural-product':
        return companies.filter(c => c.category === 'natural-product');
      case 'virtual-cell':
        return companies.filter(c => c.category === 'virtual-cell');
      default:
        return companies;
    }
  };

  // Handle daily update
  const handleUpdate = useCallback(async () => {
    setIsUpdating(true);
    
    // Simulate update process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // In a real implementation, this would:
    // 1. Fetch latest IF data from Journal Citation Reports
    // 2. Update citation counts from Google Scholar/PubMed
    // 3. Check resource link validity
    // 4. Update tech blog stats
    // 5. Refresh GitHub project stats
    
    setIsUpdating(false);
    alert('更新完成！\n- 文献IF和引用数已更新\n- 资源链接有效性已检查\n- 技术知识点已同步');
  }, []);

  return (
    <div className="min-h-screen bg-[#0a1628] text-white">
      {/* Navigation */}
      <Navbar
        sections={allSections}
        activeSection={activeSection}
        onSectionChange={setActiveSection}
      />

      {/* Hero Section */}
      <Hero onUpdate={handleUpdate} isUpdating={isUpdating} />

      {/* Main Content */}
      <main className="relative">
        {currentSection && (
          <>
            {/* Workflow */}
            <Workflow
              image={currentSection.workflowImage}
              sectionName={currentSection.nameCN}
            />

            {/* Divider */}
            <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
              <div className="h-px bg-gradient-to-r from-transparent via-slate-700/50 to-transparent" />
            </div>

            {/* Literature Review */}
            <LiteratureReview
              papers={currentSection.papers}
              sectionName={currentSection.nameCN}
            />

            {/* Divider */}
            <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
              <div className="h-px bg-gradient-to-r from-transparent via-slate-700/50 to-transparent" />
            </div>

            {/* Latest Papers by Tech Point */}
            <LatestPapers
              techPoints={currentSection.techPoints}
              sectionName={currentSection.nameCN}
            />

            {/* Divider */}
            <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
              <div className="h-px bg-gradient-to-r from-transparent via-slate-700/50 to-transparent" />
            </div>

            {/* Resources */}
            <Resources
              resources={currentSection.resources}
              sectionName={currentSection.nameCN}
            />

            {/* Divider */}
            <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
              <div className="h-px bg-gradient-to-r from-transparent via-slate-700/50 to-transparent" />
            </div>

            {/* Companies */}
            <Companies
              companies={getRelevantCompanies()}
              sectionName={currentSection.nameCN}
            />

            {/* Divider */}
            <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
              <div className="h-px bg-gradient-to-r from-transparent via-slate-700/50 to-transparent" />
            </div>

            {/* Tech Blogs */}
            <TechBlogs
              blogs={currentSection.techBlogs}
              sectionName={currentSection.nameCN}
            />

            {/* Divider */}
            {currentSection.techBlogs.length > 0 && currentSection.githubProjects.length > 0 && (
              <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
                <div className="h-px bg-gradient-to-r from-transparent via-slate-700/50 to-transparent" />
              </div>
            )}

            {/* GitHub Projects */}
            <GitHubProjects
              projects={currentSection.githubProjects}
              sectionName={currentSection.nameCN}
            />
          </>
        )}
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}

export default App;
