export interface Paper {
  id: string;
  title: string;
  authors: string;
  journal: string;
  year: number;
  citations: number;
  abstract: string;
  url: string;
  hasCode?: boolean;
  codeUrl?: string;
  impactFactor?: number;
  publishDate?: string;
  source?: 'PubMed' | 'arXiv' | 'Google Scholar';
}

export interface TechPoint {
  name: string;
  papers: Paper[];
}

export interface Resource {
  id: string;
  title: string;
  author?: string;
  type: 'book' | 'course' | 'blog' | 'video';
  url: string;
  description: string;
  isFree: boolean;
  price?: string;
  platform?: string;
  views?: string;
  likes?: string;
  rating?: string;
  purchaseLinks?: PurchaseLink[];
}

export interface PurchaseLink {
  platform: string;
  url: string;
  price: string;
}

export interface Company {
  id: string;
  name: string;
  nameCN?: string;
  description: string;
  website: string;
  location: 'domestic' | 'international';
  tags: string[];
  logo?: string;
  isDuplicate?: boolean;
  category?: string;
  country?: string;
  founded?: number;
}

export interface TechBlog {
  id: string;
  name: string;
  url: string;
  description: string;
  platform: string;
}

export interface GitHubProject {
  id: string;
  name: string;
  url: string;
  description: string;
  stars: string;
  forks: string;
  language: string;
  tags: string[];
}

export interface Section {
  id: string;
  name: string;
  nameCN: string;
  icon: string;
  papers: Paper[];
  techPoints: TechPoint[];
  resources: Resource[];
  companies: Company[];
  techBlogs: TechBlog[];
  githubProjects: GitHubProject[];
  workflowImage: string;
}

export type SortOption = 'date' | 'impact';

export interface UpdateStatus {
  lastUpdate: string;
  isUpdating: boolean;
  progress: number;
}
