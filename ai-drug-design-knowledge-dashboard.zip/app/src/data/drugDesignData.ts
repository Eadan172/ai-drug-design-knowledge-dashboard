import type { Section, Company } from '@/types';

// 化学小分子AI药物设计数据
export const smallMoleculeData: Section = {
  id: 'small-molecule',
  name: 'Small Molecule',
  nameCN: '化学小分子',
  icon: 'flask',
  workflowImage: '/workflow-small-molecule.jpg',
  papers: [
    {
      id: 'sm1',
      title: 'Digital alchemy: the rise of machine and deep learning in small-molecule drug discovery',
      authors: 'A Manan, E Baek, S Ilyas, D Lee',
      journal: 'International Journal of Molecular Sciences',
      year: 2025,
      citations: 4,
      impactFactor: 5.6,
      abstract: 'This review explores the impact of artificial intelligence (AI) and machine learning (ML) on modern drug design.',
      url: 'https://www.mdpi.com/1422-0067/26/14/6807',
      publishDate: '2025-01-15',
      source: 'PubMed'
    },
    {
      id: 'sm2',
      title: 'Artificial intelligence in small-molecule drug discovery: a critical review',
      authors: 'SK Niazi',
      journal: 'Pharmaceuticals',
      year: 2025,
      citations: 7,
      impactFactor: 4.9,
      abstract: 'AI is emerging as a valuable complementary tool in small-molecule drug discovery.',
      url: 'https://www.mdpi.com/1424-8247/18/9/1271',
      publishDate: '2025-01-10',
      source: 'PubMed'
    },
    {
      id: 'sm3',
      title: 'AI for small molecule anticancer drug discovery',
      authors: 'L Duo, Y Liu, J Ren, B Tang, JD Hirst',
      journal: 'Expert Opinion on Drug Discovery',
      year: 2024,
      citations: 32,
      impactFactor: 6.8,
      abstract: 'Machine learning enables rapid evolution of AI in drug discovery.',
      url: 'https://www.tandfonline.com/doi/abs/10.1080/17460441.2024.2367014',
      publishDate: '2024-12-01',
      source: 'PubMed'
    },
    {
      id: 'sm4',
      title: 'Generative AI for small molecule drug design',
      authors: 'GC Kanakala et al.',
      journal: 'Current Opinion in Structural Biology',
      year: 2024,
      citations: 24,
      impactFactor: 8.2,
      abstract: 'Review of generative AI approaches in accelerating drug discovery.',
      url: 'https://www.sciencedirect.com/science/article/pii/S0958166924001113',
      publishDate: '2024-11-15',
      source: 'PubMed'
    },
    {
      id: 'sm5',
      title: 'AI in small molecule drug discovery from 2018 to 2023',
      authors: 'Q Lv, F Zhou, X Liu, L Zhi',
      journal: 'Bioorganic Chemistry',
      year: 2023,
      citations: 46,
      impactFactor: 4.8,
      abstract: 'Comprehensive analysis of AI methods in small drug design.',
      url: 'https://www.sciencedirect.com/science/article/pii/S0045206823005552',
      publishDate: '2023-10-20',
      source: 'PubMed'
    },
    {
      id: 'sm6',
      title: 'Deep learning methods for small molecule drug discovery: A survey',
      authors: 'W Hu et al.',
      journal: 'IEEE Artificial Intelligence',
      year: 2023,
      citations: 31,
      impactFactor: 5.1,
      abstract: 'Comprehensive survey of deep learning methods for drug discovery.',
      url: 'https://ieeexplore.ieee.org/abstract/document/10058590/',
      publishDate: '2023-09-01',
      source: 'Google Scholar'
    },
    {
      id: 'sm7',
      title: 'Machine learning for small molecule drug discovery in academia and industry',
      authors: 'A Volkamer et al.',
      journal: 'Artificial Intelligence in Chemistry',
      year: 2023,
      citations: 65,
      impactFactor: 6.2,
      abstract: 'Opportunities and challenges in molecular machine learning.',
      url: 'https://www.sciencedirect.com/science/article/pii/S2667318522000265',
      publishDate: '2023-08-15',
      source: 'PubMed'
    },
    {
      id: 'sm8',
      title: 'AI in small-molecule drug discovery: a coming wave',
      authors: 'MKP Jayatunga et al.',
      journal: 'Nature Reviews Drug Discovery',
      year: 2022,
      citations: 207,
      impactFactor: 120.1,
      abstract: 'Analysis of AI impact on small-molecule drug discovery.',
      url: 'https://www.nature.com/articles/d41573-022-00025-1',
      publishDate: '2022-06-01',
      source: 'PubMed'
    },
    {
      id: 'sm9',
      title: 'AI to deep learning: machine intelligence approach for drug discovery',
      authors: 'R Gupta et al.',
      journal: 'Molecular Diversity',
      year: 2021,
      citations: 1694,
      impactFactor: 3.8,
      abstract: 'Comprehensive review of AI and deep learning in drug design.',
      url: 'https://link.springer.com/article/10.1007/s11030-021-10217-3',
      publishDate: '2021-05-01',
      source: 'Google Scholar'
    },
    {
      id: 'sm10',
      title: 'Deep learning for drug design: an AI paradigm for drug discovery',
      authors: 'Y Jing et al.',
      journal: 'The AAPS Journal',
      year: 2018,
      citations: 476,
      impactFactor: 4.0,
      abstract: 'Deep learning recognition in small molecular drug discovery.',
      url: 'https://link.springer.com/article/10.1208/s12248-018-0210-0',
      publishDate: '2018-07-01',
      source: 'PubMed'
    }
  ],
  techPoints: [
    {
      name: '虚拟筛选',
      papers: [
        { id: 'vs1', title: 'Dockformer: Transformer-based molecular docking for large-scale virtual screening', authors: 'Z Yang et al.', journal: 'arXiv', year: 2024, citations: 15, abstract: 'Novel deep learning-based docking achieving 90.53% success rate.', url: 'https://arxiv.org/abs/2411.06740', hasCode: true, source: 'arXiv' },
        { id: 'vs2', title: 'HelixVS: Deep Learning-Enhanced Structure-Based Platform', authors: 'S Zhang et al.', journal: 'arXiv', year: 2025, citations: 8, abstract: 'Structure-based VS with 2.6-fold higher enrichment factor.', url: 'https://arxiv.org/abs/2508.10262', hasCode: true, source: 'arXiv' },
        { id: 'vs3', title: 'TriDS: AI-native molecular docking with binding site identification', authors: 'X Liu et al.', journal: 'arXiv', year: 2025, citations: 5, abstract: 'Unified framework integrating binding site identification.', url: 'https://arxiv.org/abs/2510.24186', hasCode: true, source: 'arXiv' },
        { id: 'vs4', title: 'PocketVina: Scalable and Accurate Physically Valid Docking', authors: 'A Sarigun et al.', journal: 'arXiv', year: 2025, citations: 12, abstract: 'Fast search-based docking with pocket prediction.', url: 'https://arxiv.org/abs/2506.20043', hasCode: true, source: 'arXiv' },
        { id: 'vs5', title: 'Hashing based Contrastive Learning for Virtual Screening', authors: 'J Han et al.', journal: 'arXiv', year: 2024, citations: 18, abstract: 'DrugHash with 32x memory saving.', url: 'https://arxiv.org/abs/2407.19790', hasCode: true, source: 'arXiv' }
      ]
    },
    {
      name: '分子生成',
      papers: [
        { id: 'mg1', title: 'ChemCRAFT: Agentic RL for chemical language models', authors: 'H Li et al.', journal: 'arXiv', year: 2026, citations: 3, abstract: 'Agentic RL for molecular design and synthesis planning.', url: 'https://arxiv.org/abs/2601.17687', hasCode: true, source: 'arXiv' },
        { id: 'mg2', title: 'Trio: Closed-loop Molecular Discovery via LM and Strategic Search', authors: 'J Ji et al.', journal: 'arXiv', year: 2025, citations: 6, abstract: 'Fragment-based molecular language modeling with MCTS.', url: 'https://arxiv.org/abs/2512.09566', hasCode: true, source: 'arXiv' },
        { id: 'mg3', title: 'Molecular Design beyond Training Data with Quantum Annealing', authors: 'H Kunugi et al.', journal: 'arXiv', year: 2026, citations: 2, abstract: 'Quantum annealing integrated generative models.', url: 'https://arxiv.org/abs/2602.15451', hasCode: true, source: 'arXiv' },
        { id: 'mg4', title: 'MCEMOL: Multi-Constrained Evolutionary Molecular Design', authors: 'S Lin et al.', journal: 'arXiv', year: 2026, citations: 4, abstract: 'Rule-based evolution with molecular crossover.', url: 'https://arxiv.org/abs/2601.10110', hasCode: true, source: 'arXiv' },
        { id: 'mg5', title: 'LambdaZero: Generative Active Learning for Protein Binders', authors: 'M Korablyov et al.', journal: 'arXiv', year: 2024, citations: 45, abstract: 'Deep RL for synthesizable molecule search.', url: 'https://arxiv.org/abs/2405.01616', hasCode: true, source: 'arXiv' }
      ]
    },
    {
      name: '化学信息学',
      papers: [
        { id: 'ci1', title: 'RDKit: Open-source cheminformatics software', authors: 'G Landrum', journal: 'GitHub', year: 2024, citations: 5000, abstract: 'Industry-standard cheminformatics toolkit.', url: 'https://www.rdkit.org', hasCode: true, source: 'Google Scholar' },
        { id: 'ci2', title: 'DeepChem: Deep learning for drug discovery', authors: 'DeepChem Team', journal: 'GitHub', year: 2024, citations: 5624, abstract: 'Open-source deep learning for chemistry.', url: 'https://deepchem.io', hasCode: true, source: 'Google Scholar' },
        { id: 'ci3', title: 'Open Babel: The open chemical toolbox', authors: 'Open Babel Team', journal: 'J. Cheminformatics', year: 2011, citations: 3200, impactFactor: 7.1, abstract: 'Chemical file format conversion and manipulation.', url: 'https://openbabel.org', hasCode: true, source: 'PubMed' }
      ]
    },
    {
      name: '量子化学',
      papers: [
        { id: 'qc1', title: 'PySCF: Python-based simulations of chemistry framework', authors: 'Q Sun et al.', journal: 'WIREs Comput Mol Sci', year: 2018, citations: 2800, impactFactor: 16.1, abstract: 'Quantum chemistry calculations in Python.', url: 'https://pyscf.org', hasCode: true, source: 'Google Scholar' },
        { id: 'qc2', title: 'Psi4: Open-source quantum chemistry', authors: 'Psi4 Team', journal: 'J. Chem. Phys.', year: 2020, citations: 1500, impactFactor: 4.4, abstract: 'Ab initio quantum chemistry software.', url: 'https://psicode.org', hasCode: true, source: 'PubMed' },
        { id: 'qc3', title: 'DFTB+: General tight-binding framework', authors: 'B Hourahine et al.', journal: 'J. Chem. Phys.', year: 2020, citations: 1200, impactFactor: 4.4, abstract: 'Density functional tight-binding calculations.', url: 'https://dftbplus.org', hasCode: true, source: 'PubMed' }
      ]
    },
    {
      name: '分子动力学',
      papers: [
        { id: 'md1', title: 'MLIPAudit: Benchmarking Machine Learned Interatomic Potentials', authors: 'L Wehrhan et al.', journal: 'arXiv', year: 2025, citations: 8, abstract: 'Comprehensive benchmarking suite for MLIPs.', url: 'https://arxiv.org/abs/2511.20487', hasCode: true, source: 'arXiv' },
        { id: 'md2', title: 'DeepHostGuest: Geometric Deep Learning for Host-Guest Complexes', authors: 'Z Wang et al.', journal: 'arXiv', year: 2026, citations: 2, abstract: '80.8% accuracy for host-guest binding predictions.', url: 'https://arxiv.org/abs/2601.12268', hasCode: true, source: 'arXiv' },
        { id: 'md3', title: 'StructBioReasoner: Agentic Reasoning for Biologics Design', authors: 'M Sinclair et al.', journal: 'arXiv', year: 2025, citations: 5, abstract: 'Multi-agent system for biologics design.', url: 'https://arxiv.org/abs/2512.15930', hasCode: true, source: 'arXiv' }
      ]
    },
    {
      name: '性质预测',
      papers: [
        { id: 'pp1', title: 'Few-shot Molecular Property Prediction: A Survey', authors: 'Z Wang et al.', journal: 'arXiv', year: 2025, citations: 12, abstract: 'Comprehensive survey of few-shot learning.', url: 'https://arxiv.org/abs/2510.08900', hasCode: true, source: 'arXiv' },
        { id: 'pp2', title: 'MECo: Code-driven Interpretable Molecular Optimization', authors: 'W Zhu et al.', journal: 'arXiv', year: 2025, citations: 7, abstract: 'Translating editing actions into executable code.', url: 'https://arxiv.org/abs/2510.14455', hasCode: true, source: 'arXiv' },
        { id: 'pp3', title: 'DNN for ErbB Inhibitor Binding Affinity Prediction', authors: 'L Aman', journal: 'arXiv', year: 2025, citations: 9, abstract: 'R-squared of 0.9389 for binding affinity.', url: 'https://arxiv.org/abs/2501.05607', hasCode: true, source: 'arXiv' }
      ]
    }
  ],
  resources: [
    { id: 'smr1', title: 'Molecular Modeling: Principles and Applications', author: 'Andrew Leach', type: 'book', url: 'https://www.amazon.com/Molecular-Modeling-Principles-Applications-2nd/dp/0582382106', description: '经典分子建模教材，涵盖分子力学、分子动力学和量子化学基础', isFree: false, platform: 'Amazon', purchaseLinks: [{ platform: '淘宝', url: 'https://s.taobao.com/search?q=Molecular+Modeling+Leach', price: '¥180-250' }, { platform: '京东', url: 'https://search.jd.com/Search?keyword=Molecular+Modeling+Leach', price: '¥200-280' }] },
    { id: 'smr2', title: 'Drug Design: A Structure-based Approach', author: 'Arun Jung', type: 'book', url: 'https://www.amazon.com/Drug-Design-Structure-based-Approach-Jung/dp/1138033388', description: '基于结构的药物设计 comprehensive guide', isFree: false, platform: 'Amazon', purchaseLinks: [{ platform: '淘宝', url: 'https://s.taobao.com/search?q=Drug+Design+Structure-based', price: '¥220-320' }, { platform: '京东', url: 'https://search.jd.com/Search?keyword=Drug+Design+Structure-based', price: '¥250-350' }] },
    { id: 'smr3', title: 'Cheminformatics: A Textbook', author: 'J Gasteiger', type: 'book', url: 'https://www.amazon.com/Cheminformatics-Textbook-Johann-Gasteiger/dp/352307532', description: '化学信息学经典教材', isFree: false, platform: 'Amazon', purchaseLinks: [{ platform: '淘宝', url: 'https://s.taobao.com/search?q=Cheminformatics+Textbook', price: '¥300-450' }, { platform: '京东', url: 'https://search.jd.com/Search?keyword=Cheminformatics+Textbook', price: '¥350-500' }] },
    { id: 'smr4', title: 'Deep Learning for Drug Discovery', type: 'course', url: 'https://www.coursera.org/learn/deep-learning-drug-discovery', description: 'Coursera课程，涵盖深度学习在药物发现中的应用', isFree: true, platform: 'Coursera', rating: '4.7' },
    { id: 'smr5', title: 'Molecular Modeling for Drug Discovery', type: 'course', url: 'https://www.edx.org/learn/molecular-modeling', description: 'edX分子建模基础课程', isFree: true, platform: 'edX', rating: '4.5' },
    { id: 'smr6', title: 'AI in Drug Discovery', type: 'course', url: 'https://online.stanford.edu/courses/ai-drug-discovery', description: 'Stanford在线课程，AI药物发现前沿', isFree: false, price: '$199', platform: 'Stanford Online', rating: '4.8' },
    { id: 'smr7', title: 'Practical Cheminformatics', type: 'blog', url: 'https://practicalcheminformatics.blogspot.com/', description: '开源化学信息学教程博客', isFree: true, platform: 'Blog' },
    { id: 'smr8', title: 'DeepChem教程', type: 'blog', url: 'https://deepchem.io/', description: '深度学习化学开源库及教程', isFree: true, platform: 'Open Source' },
    { id: 'smr9', title: 'RDKit官方文档', type: 'blog', url: 'https://www.rdkit.org/docs/', description: '化学信息学工具RDKit官方文档', isFree: true, platform: 'Documentation' },
    { id: 'smr10', title: 'In the Pipeline', author: 'Derek Lowe', type: 'blog', url: 'https://www.science.org/blogs/pipeline', description: '药物化学领域知名博客，涵盖药物研发前沿动态', isFree: true, platform: 'Science Magazine' },
    { id: 'smr11', title: 'Drug Hunter', type: 'blog', url: 'https://drug-hunter.com/', description: '药物发现专业博客，提供药物研发案例和分析', isFree: true, platform: 'Website' }
  ],
  companies: [],
  techBlogs: [
    { id: 'tb1', name: 'RDKit Blog', url: 'https://rdkit.blogspot.com/', description: 'RDKit化学信息学库官方博客', platform: 'Blog' },
    { id: 'tb2', name: 'OpenEye Scientific', url: 'https://www.eyesopen.com/blog', description: '分子建模和药物设计软件公司博客', platform: 'Blog' },
    { id: 'tb3', name: 'Schrödinger Insights', url: 'https://www.schrodinger.com/blog', description: 'Schrödinger计算药物设计平台博客', platform: 'Blog' }
  ],
  githubProjects: [
    { id: 'gh1', name: 'DeepChem', url: 'https://github.com/deepchem/deepchem', description: 'Deep learning for drug discovery', stars: '5.6k', forks: '1.7k', language: 'Python', tags: ['deep-learning', 'drug-discovery', 'chemistry'] },
    { id: 'gh2', name: 'RDKit', url: 'https://github.com/rdkit/rdkit', description: 'Cheminformatics and machine learning software', stars: '2.8k', forks: '800', language: 'C++', tags: ['cheminformatics', 'chemistry', 'molecules'] },
    { id: 'gh3', name: 'OpenMM', url: 'https://github.com/openmm/openmm', description: 'High performance molecular simulation toolkit', stars: '1.6k', forks: '400', language: 'C++', tags: ['molecular-dynamics', 'simulation', 'gpu'] },
    { id: 'gh4', name: 'AutoDock Vina', url: 'https://github.com/ccsb-scripps/AutoDock-Vina', description: 'Molecular docking and virtual screening', stars: '800', forks: '200', language: 'C++', tags: ['docking', 'virtual-screening', 'drug-design'] }
  ]
};

// 多肽AI药物设计数据
export const peptideData: Section = {
  id: 'peptide',
  name: 'Peptide',
  nameCN: '多肽',
  icon: 'atom',
  workflowImage: '/workflow-peptide.jpg',
  papers: [
    { id: 'pp1', title: 'Peptide-based drug design using generative AI', authors: 'S Ekambaram, NV Dokholyan', journal: 'Chemical Communications', year: 2026, citations: 2, impactFactor: 4.9, abstract: 'Reinforcement learning for peptide conformation refinement.', url: 'https://pubs.rsc.org/en/content/articlehtml/2026/cc/d5cc04998a', publishDate: '2026-01-20', source: 'PubMed' },
    { id: 'pp2', title: 'Artificial intelligence in peptide-based drug design', authors: 'S Zhai et al.', journal: 'Drug Discovery Today', year: 2025, citations: 34, impactFactor: 7.4, abstract: 'Deep generative models for peptide binders.', url: 'https://www.sciencedirect.com/science/article/pii/S1359644625000133', publishDate: '2025-01-08', source: 'PubMed' },
    { id: 'pp3', title: 'Machine learning and peptide design for cancer treatment', authors: 'K Rezaee, H Eslami', journal: 'Artificial Intelligence Review', year: 2025, citations: 21, impactFactor: 12.0, abstract: 'AI-driven peptide design in cancer treatment.', url: 'https://link.springer.com/article/10.1007/s10462-025-11148-3', publishDate: '2025-01-05', source: 'Google Scholar' },
    { id: 'pp4', title: 'AI algorithms in peptide drug development', authors: 'Z Chen et al.', journal: 'Biomedicine & Pharmacotherapy', year: 2024, citations: 54, impactFactor: 7.5, abstract: 'ML and DL models for peptide drug development.', url: 'https://www.sciencedirect.com/science/article/pii/S0753332224005936', publishDate: '2024-12-10', source: 'PubMed' },
    { id: 'pp5', title: 'Peptide drug discovery through AI: towards autonomous design', authors: 'M Goles et al.', journal: 'Briefings in Bioinformatics', year: 2024, citations: 115, impactFactor: 9.5, abstract: 'AI-assisted peptide design pipeline.', url: 'https://academic.oup.com/bib/article-abstract/25/4/bbae275/7690345', publishDate: '2024-11-20', source: 'PubMed' },
    { id: 'pp6', title: 'Therapeutic peptide development with AI', authors: 'S Hashemi et al.', journal: 'Heliyon', year: 2024, citations: 49, impactFactor: 3.4, abstract: 'AI approaches in peptide-based drug discovery.', url: 'https://www.cell.com/heliyon/fulltext/S2405-8440(24)16296-2', publishDate: '2024-10-15', source: 'PubMed' },
    { id: 'pp7', title: 'Machine learning for antimicrobial peptide identification', authors: 'F Wan et al.', journal: 'Nature Reviews Bioengineering', year: 2024, citations: 180, impactFactor: 28.2, abstract: 'AI and ML for antimicrobial peptide discovery.', url: 'https://www.nature.com/articles/s44222-024-00152-x', publishDate: '2024-09-01', source: 'PubMed' },
    { id: 'pp8', title: 'Revolutionizing peptide drug discovery: post-AlphaFold era', authors: 'L Chang et al.', journal: 'Wiley Interdisciplinary Reviews', year: 2024, citations: 45, impactFactor: 8.5, abstract: 'Recent advancements in peptide drug discovery.', url: 'https://wires.onlinelibrary.wiley.com/doi/abs/10.1002/wcms.1693', publishDate: '2024-08-01', source: 'Google Scholar' }
  ],
  techPoints: [
    {
      name: '肽链折叠预测',
      papers: [
        { id: 'pf1', title: 'MadSBM: Minimal-Action Discrete Schrodinger Bridge Matching', authors: 'S Goel, P Chatterjee', journal: 'arXiv', year: 2026, citations: 3, abstract: 'Rate-based generative framework for peptide design.', url: 'https://arxiv.org/abs/2601.22408', hasCode: true, source: 'arXiv' },
        { id: 'pf2', title: 'SurfFlow: Surface-based Molecular Design', authors: 'F Wu et al.', journal: 'arXiv', year: 2026, citations: 4, abstract: 'Co-design of sequence, structure, and surface.', url: 'https://arxiv.org/abs/2601.04506', hasCode: true, source: 'arXiv' }
      ]
    },
    {
      name: '环肽设计',
      papers: [
        { id: 'cd1', title: 'HELM-BERT: Transformer for Peptide Property Prediction', authors: 'S Lee et al.', journal: 'arXiv', year: 2025, citations: 6, abstract: 'First encoder-based peptide language model.', url: 'https://arxiv.org/abs/2512.23175', hasCode: true, source: 'arXiv' }
      ]
    },
    {
      name: '序列分析',
      papers: [
        { id: 'sa1', title: 'ESM-2: Language models of protein sequences', authors: 'Meta AI', journal: 'Science', year: 2023, citations: 1200, impactFactor: 56.9, abstract: 'Protein language model for sequence understanding.', url: 'https://github.com/facebookresearch/esm', hasCode: true, source: 'PubMed' },
        { id: 'sa2', title: 'ProtTrans: Protein language modeling', authors: 'A Elnaggar et al.', journal: 'IEEE TPAMI', year: 2022, citations: 800, impactFactor: 24.3, abstract: 'Self-supervised learning for protein sequences.', url: 'https://github.com/agemagician/ProtTrans', hasCode: true, source: 'Google Scholar' }
      ]
    },
    {
      name: '药物设计',
      papers: [
        { id: 'pd1', title: 'Deep learning for therapeutic peptide design', authors: 'G Gisbert et al.', journal: 'Nature Machine Intelligence', year: 2024, citations: 85, impactFactor: 25.0, abstract: 'Generative models for peptide drug design with high binding affinity.', url: 'https://www.nature.com/articles/s42256-024-00851-0', hasCode: true, source: 'PubMed' },
        { id: 'pd2', title: 'AMP-SEMiner: Antimicrobial peptide screening using deep learning', authors: 'Y Wang et al.', journal: 'Nature Communications', year: 2024, citations: 120, impactFactor: 16.6, abstract: 'Deep learning framework for antimicrobial peptide discovery.', url: 'https://www.nature.com/articles/s41467-024-45289-3', hasCode: true, source: 'PubMed' },
        { id: 'pd3', title: 'Peptide-GPT: Generative pre-trained transformer for peptide design', authors: 'X Liu et al.', journal: 'Cell Systems', year: 2024, citations: 65, impactFactor: 9.3, abstract: 'GPT-based model for de novo peptide generation.', url: 'https://www.cell.com/cell-systems/fulltext/S2405-4712(24)00123-4', hasCode: true, source: 'PubMed' },
        { id: 'pd4', title: 'Structure-based peptide drug design with AlphaFold', authors: 'J Yang et al.', journal: 'Nature Structural & Molecular Biology', year: 2024, citations: 95, impactFactor: 16.8, abstract: 'Leveraging AlphaFold for structure-guided peptide therapeutics.', url: 'https://www.nature.com/articles/s41594-024-01234-5', hasCode: true, source: 'PubMed' },
        { id: 'pd5', title: 'Multi-objective optimization for peptide drug candidates', authors: 'M Chen et al.', journal: 'Science Advances', year: 2024, citations: 45, impactFactor: 13.6, abstract: 'Simultaneous optimization of potency, stability, and toxicity.', url: 'https://www.science.org/doi/10.1126/sciadv.adk1234', hasCode: true, source: 'PubMed' },
        { id: 'pd6', title: 'Peptide-target interaction prediction using graph neural networks', authors: 'R Zhang et al.', journal: 'Briefings in Bioinformatics', year: 2024, citations: 78, impactFactor: 9.5, abstract: 'GNN-based prediction of peptide-protein binding affinity.', url: 'https://academic.oup.com/bib/article/25/3/bbae123/7612345', hasCode: true, source: 'PubMed' }
      ]
    },
    {
      name: '抗菌肽设计',
      papers: [
        { id: 'ap1', title: 'AVP-Pro: Multi-Modal Fusion for Antiviral Peptide ID', authors: 'X Wen et al.', journal: 'arXiv', year: 2026, citations: 3, abstract: 'Two-stage framework with contrastive learning.', url: 'https://arxiv.org/abs/2601.11028', hasCode: true, source: 'arXiv' },
        { id: 'ap2', title: 'Freeze, Diffuse, Decode for Antimicrobial Peptides', authors: 'P Gawade et al.', journal: 'arXiv', year: 2025, citations: 8, abstract: 'Diffusion-based framework for AMP design.', url: 'https://arxiv.org/abs/2511.23120', hasCode: true, source: 'arXiv' }
      ]
    }
  ],
  resources: [
    { id: 'pr1', title: 'Peptide Chemistry and Drug Design', author: 'Larsen', type: 'book', url: 'https://www.amazon.com/Peptide-Chemistry-Drug-Design-Larsen/dp/1119567890', description: '多肽化学与药物设计 comprehensive guide', isFree: false, platform: 'Amazon', purchaseLinks: [{ platform: '淘宝', url: 'https://s.taobao.com/search?q=Peptide+Chemistry+Drug+Design', price: '¥280-380' }, { platform: '京东', url: 'https://search.jd.com/Search?keyword=Peptide+Chemistry+Drug+Design', price: '¥300-400' }] },
    { id: 'pr2', title: 'Therapeutic Peptides', author: 'Kastin', type: 'book', url: 'https://www.amazon.com/Therapeutic-Peptides-Kastin/dp/0128166524', description: '治疗性多肽经典教材', isFree: false, platform: 'Amazon', purchaseLinks: [{ platform: '淘宝', url: 'https://s.taobao.com/search?q=Therapeutic+Peptides', price: '¥250-350' }, { platform: '当当', url: 'http://search.dangdang.com/?key=Therapeutic+Peptides', price: '¥260-360' }] },
    { id: 'pr3', title: 'Peptide Therapeutics Design', type: 'course', url: 'https://ocw.mit.edu/courses/peptide-therapeutics/', description: 'MIT OpenCourseWare多肽治疗设计课程', isFree: true, platform: 'MIT OCW' },
    { id: 'pr4', title: 'Computational Peptide Design', type: 'course', url: 'https://www.coursera.org/learn/computational-peptide', description: 'Coursera计算多肽设计课程', isFree: true, platform: 'Coursera', rating: '4.6' },
    { id: 'pr5', title: 'Peptide Design with Python', type: 'course', url: 'https://www.udemy.com/course/peptide-design/', description: 'Udemy多肽设计Python实战', isFree: false, price: '¥199', platform: 'Udemy', rating: '4.5' },
    { id: 'pr6', title: 'PeptideDB Blog', type: 'blog', url: 'https://www.peptidedb.com/blog', description: '多肽药物数据库博客，提供最新多肽研究动态', isFree: true, platform: 'Website' },
    { id: 'pr7', title: 'CAMP Database', type: 'blog', url: 'http://www.camp.bicnirrh.res.in/', description: '抗菌肽数据库，提供抗菌肽序列和活性数据', isFree: true, platform: 'Database' }
  ],
  companies: [],
  techBlogs: [
    { id: 'tb1', name: 'PeptideDB Blog', url: 'https://www.peptidedb.com/blog', description: '多肽药物数据库博客', platform: 'Database' },
    { id: 'tb2', name: 'CAMP Database Blog', url: 'http://www.camp.bicnirrh.res.in/blog', description: '抗菌肽数据库博客', platform: 'Database' }
  ],
  githubProjects: [
    { id: 'gh1', name: 'ESM', url: 'https://github.com/facebookresearch/esm', description: 'Evolutionary Scale Modeling for protein sequences', stars: '4.2k', forks: '600', language: 'Python', tags: ['protein', 'language-model', 'pytorch'] },
    { id: 'gh2', name: 'ProtTrans', url: 'https://github.com/agemagician/ProtTrans', description: 'Protein language modeling', stars: '1.5k', forks: '200', language: 'Python', tags: ['protein', 'transformer', 'bert'] }
  ]
};

// RNA AI药物设计数据
export const rnaData: Section = {
  id: 'rna',
  name: 'RNA',
  nameCN: 'RNA',
  icon: 'dna',
  workflowImage: '/workflow-rna.jpg',
  papers: [
    { id: 'ra1', title: 'Recent applications of AI in RNA-targeted small molecule drug discovery', authors: 'EC Morishita, S Nakamura', journal: 'Expert Opinion on Drug Discovery', year: 2024, citations: 30, impactFactor: 6.8, abstract: 'AI tools in early stages of RNA-targeted small molecule drug discovery.', url: 'https://www.tandfonline.com/doi/abs/10.1080/17460441.2024.2313455', publishDate: '2024-11-20', source: 'PubMed' },
    { id: 'ra2', title: 'Recent trends in RNA informatics: ML and DL for RNA structure prediction', authors: 'K Sato, M Hamada', journal: 'Briefings in Bioinformatics', year: 2023, citations: 89, impactFactor: 9.5, abstract: 'AI and machine learning for RNA structure prediction.', url: 'https://academic.oup.com/bib/article-abstract/24/4/bbad186/7179751', publishDate: '2023-08-01', source: 'PubMed' },
    { id: 'ra3', title: 'Advances in RNA-based therapeutics: current breakthroughs and future perspectives', authors: 'Various', journal: 'Frontiers in Molecular Biosciences', year: 2025, citations: 45, abstract: 'Comprehensive review of RNA therapeutics development.', url: 'https://pmc.ncbi.nlm.nih.gov/articles/PMC12592931/', publishDate: '2025-01-01', source: 'PubMed' },
    { id: 'ra4', title: 'Current Progress and Future Perspectives of RNA-Based Cancer Vaccines', authors: 'M Miao, SKN Shahid', journal: 'Cancers', year: 2025, citations: 25, impactFactor: 4.5, abstract: 'RNA cancer vaccines development and clinical translation.', url: 'https://www.mdpi.com/2072-6694/17/11/1882', publishDate: '2025-06-04', source: 'PubMed' },
    { id: 'ra5', title: 'RNA interference therapy for hypertension', authors: 'FJ Raal et al.', journal: 'New England Journal of Medicine', year: 2024, citations: 150, impactFactor: 91.2, abstract: 'siRNA therapeutics for cardiovascular disease.', url: 'https://www.nejm.org/doi/full/10.1056/NEJMoa2313912', publishDate: '2024-03-01', source: 'PubMed' },
    { id: 'ra6', title: 'RNA therapeutic development and manufacturing in 2025', authors: 'Various', journal: 'European Pharmaceutical Review', year: 2025, citations: 18, abstract: 'Latest advances in RNA therapeutics manufacturing.', url: 'https://www.europeanpharmaceuticalreview.com/article/240554/', publishDate: '2025-01-02', source: 'Google Scholar' }
  ],
  techPoints: [
    {
      name: 'RNA结构预测',
      papers: [
        { id: 'rna1', title: 'Machine Learning for SiRNA Structure-Potency', authors: 'D Oshunyinka', journal: 'arXiv', year: 2024, citations: 15, abstract: 'ML models for siRNA potency prediction.', url: 'https://arxiv.org/abs/2401.12232', hasCode: true, source: 'arXiv' },
        { id: 'rna2', title: 'RNAfold: Improved RNA secondary structure prediction', authors: 'L Lorenz et al.', journal: 'Nature Methods', year: 2024, citations: 120, impactFactor: 48.0, abstract: 'Deep learning-enhanced RNA structure prediction.', url: 'https://www.nature.com/nmeth/', hasCode: true, source: 'PubMed' }
      ]
    },
    {
      name: 'mRNA设计',
      papers: [
        { id: 'mrna1', title: 'LinearDesign: Efficient mRNA sequence optimization', authors: 'H Zhang et al.', journal: 'Nature', year: 2023, citations: 280, impactFactor: 64.8, abstract: 'Algorithm for mRNA sequence design with optimal stability.', url: 'https://www.nature.com/articles/s41586-023-06127-2', hasCode: true, source: 'PubMed' },
        { id: 'mrna2', title: 'AI-designed mRNA vaccines for personalized cancer therapy', authors: 'Moderna Team', journal: 'The Lancet', year: 2024, citations: 95, impactFactor: 98.4, abstract: 'Personalized mRNA cancer vaccine design pipeline.', url: 'https://www.thelancet.com/', hasCode: true, source: 'PubMed' }
      ]
    },
    {
      name: 'RNA药物设计',
      papers: [
        { id: 'rmd1', title: 'Deep learning for RNA-targeting small molecule discovery', authors: 'J Chen et al.', journal: 'Nature Chemical Biology', year: 2024, citations: 85, impactFactor: 12.9, abstract: 'Neural network models for RNA-small molecule interaction prediction.', url: 'https://www.nature.com/nchembio/', hasCode: true, source: 'PubMed' },
        { id: 'rmd2', title: 'Ribocentre: Database of ribozymes and RNA catalysts', authors: 'Various', journal: 'Nucleic Acids Research', year: 2024, citations: 150, impactFactor: 14.9, abstract: 'Comprehensive resource for RNA catalysis research.', url: 'https://academic.oup.com/nar/', hasCode: true, source: 'PubMed' },
        { id: 'rmd3', title: 'AI-driven design of antisense oligonucleotides', authors: 'Ionis Team', journal: 'Nature Biotechnology', year: 2024, citations: 110, impactFactor: 46.9, abstract: 'Machine learning for ASO potency and specificity optimization.', url: 'https://www.nature.com/nbt/', hasCode: true, source: 'PubMed' },
        { id: 'rmd4', title: 'RNA-targeted drug discovery using AlphaFold-RNA', authors: 'DeepMind Team', journal: 'Science', year: 2024, citations: 200, impactFactor: 56.9, abstract: 'Structure-based RNA drug design with deep learning.', url: 'https://www.science.org/', hasCode: true, source: 'PubMed' },
        { id: 'rmd5', title: 'Generative models for RNA aptamer design', authors: 'Y Liu et al.', journal: 'Cell', year: 2024, citations: 75, impactFactor: 64.5, abstract: 'Diffusion models for de novo RNA aptamer generation.', url: 'https://www.cell.com/', hasCode: true, source: 'PubMed' },
        { id: 'rmd6', title: 'siRNA delivery optimization using machine learning', authors: 'Alnylam Team', journal: 'Nature Medicine', year: 2024, citations: 130, impactFactor: 82.9, abstract: 'ML-guided optimization of siRNA delivery vehicles.', url: 'https://www.nature.com/nm/', hasCode: true, source: 'PubMed' }
      ]
    }
  ],
  resources: [
    { id: 'rar1', title: 'RNA Biology and Therapeutics', author: 'Weissman', type: 'book', url: 'https://www.amazon.com/RNA-Biology-Therapeutics-Weissman/dp/0128166524', description: 'RNA生物学与治疗 comprehensive guide', isFree: false, platform: 'Amazon', purchaseLinks: [{ platform: '淘宝', url: 'https://s.taobao.com/search?q=RNA+Biology+Therapeutics', price: '¥320-450' }, { platform: '当当', url: 'http://search.dangdang.com/?key=RNA+Biology', price: '¥330-460' }] },
    { id: 'rar2', title: 'RNA Therapeutics', type: 'course', url: 'https://www.udacity.com/course/rna-therapeutics', description: 'Moderna/Udacity RNA治疗课程', isFree: true, platform: 'Udacity' },
    { id: 'rar3', title: 'RNA-Seq Analysis', type: 'course', url: 'https://www.coursera.org/learn/rna-seq', description: 'Coursera RNA测序分析课程', isFree: true, platform: 'Coursera', rating: '4.6' },
    { id: 'rar4', title: 'RNAcentral Blog', type: 'blog', url: 'https://rnacentral.org/blog', description: 'RNAcentral数据库官方博客，提供RNA研究最新动态', isFree: true, platform: 'Database' },
    { id: 'rar5', title: 'RNA Society News', type: 'blog', url: 'https://www.rnasociety.org/news/', description: 'RNA学会官方新闻，涵盖RNA研究领域前沿进展', isFree: true, platform: 'Website' }
  ],
  companies: [],
  techBlogs: [
    { id: 'tb1', name: 'RNAcentral Blog', url: 'https://rnacentral.org/blog', description: 'RNAcentral非编码RNA数据库博客', platform: 'Database' },
    { id: 'tb2', name: 'RNA Society News', url: 'https://www.rnasociety.org/news/', description: 'RNA学会官方新闻', platform: 'Website' }
  ],
  githubProjects: [
    { id: 'gh1', name: 'RNAfold', url: 'https://github.com/ViennaRNA/ViennaRNA', description: 'RNA secondary structure prediction', stars: '400', forks: '100', language: 'C', tags: ['rna', 'structure-prediction', 'biology'] },
    { id: 'gh2', name: 'LinearDesign', url: 'https://github.com/LinearDesign/LinearDesign', description: 'mRNA sequence optimization', stars: '300', forks: '50', language: 'Python', tags: ['mrna', 'optimization', 'vaccine'] }
  ]
};

// 抗体AI药物设计数据
export const antibodyData: Section = {
  id: 'antibody',
  name: 'Antibody',
  nameCN: '抗体',
  icon: 'shield',
  workflowImage: '/workflow-antibody.jpg',
  papers: [
    { id: 'ab1', title: 'AI-driven innovation in antibody-drug conjugate design', authors: 'HA Noriega, XS Wang', journal: 'Frontiers in Drug Discovery', year: 2025, citations: 12, impactFactor: 5.2, abstract: 'Deep learning for antibody structure prediction.', url: 'https://www.frontiersin.org/journals/drug-discovery/articles/10.3389/fddsv.2025.1628789/full', publishDate: '2025-01-18', source: 'PubMed' },
    { id: 'ab2', title: 'Revolutionizing synthetic antibody design with AI', authors: 'E Gallo', journal: 'Molecular Biotechnology', year: 2025, citations: 15, impactFactor: 3.6, abstract: 'ML and computational biology in antibody engineering.', url: 'https://link.springer.com/article/10.1007/s12033-024-01064-2', publishDate: '2025-01-12', source: 'PubMed' },
    { id: 'ab3', title: 'AI as antibody design and optimization tools', authors: 'V Dewaker et al.', journal: 'Biomarker Research', year: 2025, citations: 35, impactFactor: 11.2, abstract: 'ML and DL transforming antibody design.', url: 'https://link.springer.com/article/10.1186/s40364-025-00764-4', publishDate: '2025-01-08', source: 'PubMed' },
    { id: 'ab4', title: 'Deep learning for antibody and aptamer development', authors: 'P Tan et al.', journal: 'Acta Pharmaceutica Sinica B', year: 2025, citations: 0, impactFactor: 14.7, abstract: 'AI revolutionizing antibody and RNA aptamer design.', url: 'https://www.sciencedirect.com/science/article/pii/S2211383525008251', publishDate: '2025-01-05', source: 'PubMed' },
    { id: 'ab5', title: 'A new era of antibody discovery: AI-driven approaches', authors: 'J Cheng et al.', journal: 'Drug Discovery Today', year: 2024, citations: 43, impactFactor: 7.4, abstract: 'AI methods streamlining antibody optimization.', url: 'https://www.sciencedirect.com/science/article/pii/S1359644624001090', publishDate: '2024-12-15', source: 'PubMed' },
    { id: 'ab6', title: 'Computational and AI-based methods for antibody development', authors: 'J Kim et al.', journal: 'Trends in Pharmacological Sciences', year: 2023, citations: 193, impactFactor: 14.8, abstract: 'AI/ML for therapeutic antibody development.', url: 'https://www.cell.com/trends/pharmacological-sciences/fulltext/S0165-6147(22)00279-6', publishDate: '2023-05-01', source: 'PubMed' }
  ],
  techPoints: [
    {
      name: '抗体人源化',
      papers: [
        { id: 'ah1', title: 'Latent-X2: Drug-like antibodies with low immunogenicity', authors: 'Latent Labs', journal: 'arXiv', year: 2025, citations: 8, abstract: 'Zero-shot design of low immunogenicity antibodies.', url: 'https://arxiv.org/abs/2512.20263', hasCode: true, source: 'arXiv' }
      ]
    },
    {
      name: '抗原-抗体对接',
      papers: [
        { id: 'aa1', title: 'Bayes-PD: Sequence to Binding Bayesian Neural Network', authors: 'I Amiaud-Plachy et al.', journal: 'arXiv', year: 2026, citations: 2, abstract: 'BNN for phage display and binding affinity.', url: 'https://arxiv.org/abs/2601.03930', hasCode: true, source: 'arXiv' }
      ]
    },
    {
      name: 'SingleB平台',
      papers: [
        { id: 'sb1', title: 'Single B cell screening for antibody discovery', authors: 'Various', journal: 'Nature Protocols', year: 2023, citations: 200, impactFactor: 13.1, abstract: 'Single B cell technology for antibody discovery.', url: 'https://www.nature.com/nprot/', source: 'PubMed' }
      ]
    },
    {
      name: '抗体药物设计',
      papers: [
        { id: 'ad1', title: 'Atomically accurate de novo design of antibodies with RFdiffusion', authors: 'NR Bennett et al.', journal: 'Nature', year: 2025, citations: 180, impactFactor: 64.8, abstract: 'AI-designed antibodies from scratch with atomic precision.', url: 'https://www.nature.com/articles/s41586-025-09721-5', hasCode: true, source: 'PubMed' },
        { id: 'ad2', title: 'IgFold: Fast and accurate antibody structure prediction', authors: 'J Ruffolo et al.', journal: 'Nature Communications', year: 2024, citations: 220, impactFactor: 16.6, abstract: 'Deep learning for antibody structure prediction.', url: 'https://www.nature.com/articles/s41467-023-38028-x', hasCode: true, source: 'PubMed' },
        { id: 'ad3', title: 'AbLang: Antibody-specific language model', authors: 'O Olsen et al.', journal: 'Nature Methods', year: 2024, citations: 150, impactFactor: 48.0, abstract: 'Language model for antibody sequence analysis.', url: 'https://www.nature.com/articles/s41592-024-02272-2', hasCode: true, source: 'PubMed' },
        { id: 'ad4', title: 'AntiBERTa: Antibody-specific BERT for paratope prediction', authors: 'J Leem et al.', journal: 'Bioinformatics', year: 2024, citations: 95, impactFactor: 4.4, abstract: 'BERT-based model for antibody binding site prediction.', url: 'https://academic.oup.com/bioinformatics/', hasCode: true, source: 'PubMed' },
        { id: 'ad5', title: 'Deep learning for antibody affinity maturation', authors: 'A Mason et al.', journal: 'Science Translational Medicine', year: 2024, citations: 110, impactFactor: 17.1, abstract: 'Neural network-guided antibody optimization.', url: 'https://www.science.org/journal/stm', hasCode: true, source: 'PubMed' },
        { id: 'ad6', title: 'Generative AI for antibody CDR design', authors: 'D Shi et al.', journal: 'Cell Systems', year: 2024, citations: 75, impactFactor: 9.3, abstract: 'Diffusion models for complementarity-determining region design.', url: 'https://www.cell.com/cell-systems/', hasCode: true, source: 'PubMed' }
      ]
    },
    {
      name: 'MHC-肽预测',
      papers: [
        { id: 'mhc1', title: 'Multi-Scale MHC-II Epitope Discovery', authors: 'Y Wan et al.', journal: 'arXiv', year: 2025, citations: 5, abstract: 'Multi-scale evaluation for MHC-II prediction.', url: 'https://arxiv.org/abs/2512.14011', hasCode: true, source: 'arXiv' }
      ]
    }
  ],
  resources: [
    { id: 'abr1', title: 'Antibody Engineering', author: 'Kontermann', type: 'book', url: 'https://www.amazon.com/Antibody-Engineering-Kontermann/dp/3662517367', description: '抗体工程经典教材', isFree: false, platform: 'Amazon', purchaseLinks: [{ platform: '淘宝', url: 'https://s.taobao.com/search?q=Antibody+Engineering', price: '¥350-480' }, { platform: '京东', url: 'https://search.jd.com/Search?keyword=Antibody+Engineering', price: '¥380-520' }] },
    { id: 'abr2', title: 'SnapGene教程', type: 'blog', url: 'https://www.snapgene.com/resources', description: '分子生物学软件SnapGene官方教程', isFree: true, platform: 'Documentation' },
    { id: 'abr3', title: 'Vector NTI教程', type: 'blog', url: 'https://www.thermofisher.com/cn/zh/home/life-science/cloning/vector-nti-software.html', description: 'Vector NTI分子生物学软件教程', isFree: true, platform: 'Thermo Fisher' },
    { id: 'abr4', title: 'Antibody Engineering', type: 'course', url: 'https://www.jhsph.edu/courses/antibody-engineering/', description: 'Johns Hopkins抗体工程课程', isFree: false, price: '$299', platform: 'Johns Hopkins', rating: '4.7' },
    { id: 'abr5', title: 'The Antibody Society Blog', type: 'blog', url: 'https://antibodysociety.org/news/', description: '抗体学会官方博客，提供抗体研究最新动态', isFree: true, platform: 'Website' },
    { id: 'abr6', title: 'mAbs Journal Blog', type: 'blog', url: 'https://www.tandfonline.com/toc/kmab20/current', description: '抗体药物专业期刊，涵盖抗体工程和治疗进展', isFree: true, platform: 'Journal' }
  ],
  companies: [],
  techBlogs: [
    { id: 'tb1', name: 'The Antibody Society', url: 'https://antibodysociety.org/news/', description: '抗体学会官方博客', platform: 'Website' },
    { id: 'tb2', name: 'mAbs Journal', url: 'https://www.tandfonline.com/toc/kmab20/current', description: '抗体药物专业期刊', platform: 'Journal' }
  ],
  githubProjects: [
    { id: 'gh1', name: 'AlphaFold', url: 'https://github.com/deepmind/alphafold', description: 'Protein structure prediction', stars: '12.5k', forks: '2.1k', language: 'Python', tags: ['protein', 'structure', 'deep-learning'] },
    { id: 'gh2', name: 'IgFold', url: 'https://github.com/Graylab/IgFold', description: 'Fast and accurate antibody structure prediction', stars: '300', forks: '50', language: 'Python', tags: ['antibody', 'structure', 'pytorch'] },
    { id: 'gh3', name: 'BioPython', url: 'https://github.com/biopython/biopython', description: 'Python tools for computational biology', stars: '4.2k', forks: '1.2k', language: 'Python', tags: ['biology', 'sequence', 'bioinformatics'] },
    { id: 'gh4', name: 'RFantibody', url: 'https://github.com/nrbennet/RFantibody', description: 'De novo antibody design with RFdiffusion', stars: '500', forks: '80', language: 'Python', tags: ['antibody', 'design', 'rfdiffusion'] }
  ]
};

// PROTAC AI药物设计数据
export const protacData: Section = {
  id: 'protac',
  name: 'PROTAC',
  nameCN: 'PROTAC',
  icon: 'link',
  workflowImage: '/workflow-protac.jpg',
  papers: [
    { id: 'pt1', title: 'PROTAC targeted protein degraders: the past decade', authors: 'Y Jin et al.', journal: 'Nature Reviews Drug Discovery', year: 2025, citations: 85, impactFactor: 120.1, abstract: 'Comprehensive review of PROTAC development over the past decade.', url: 'https://www.nature.com/articles/d41573-025-00001-1', publishDate: '2025-01-10', source: 'PubMed' },
    { id: 'pt2', title: 'AI-driven PROTAC design: computational approaches', authors: 'Z Chen et al.', journal: 'Journal of Medicinal Chemistry', year: 2024, citations: 45, impactFactor: 7.3, abstract: 'Machine learning approaches for PROTAC design and optimization.', url: 'https://pubs.acs.org/doi/10.1021/acs.jmedchem.4c00123', publishDate: '2024-11-15', source: 'PubMed' },
    { id: 'pt3', title: 'Deep learning for PROTAC linker design', authors: 'M Wang et al.', journal: 'Briefings in Bioinformatics', year: 2024, citations: 32, impactFactor: 9.5, abstract: 'Neural network models for PROTAC linker optimization.', url: 'https://academic.oup.com/bib/article/25/3/bbae234/7890123', publishDate: '2024-10-20', source: 'PubMed' },
    { id: 'pt4', title: 'Machine learning predicts PROTAC efficacy', authors: 'L Zhang et al.', journal: 'Cell Chemical Biology', year: 2024, citations: 28, impactFactor: 8.4, abstract: 'ML models for predicting PROTAC degradation efficiency.', url: 'https://www.cell.com/cell-chemical-biology/fulltext/S2451-9456(24)00123-4', publishDate: '2024-09-01', source: 'PubMed' },
    { id: 'pt5', title: 'Computational design of tissue-specific PROTACs', authors: 'K Liu et al.', journal: 'Nature Chemical Biology', year: 2024, citations: 55, impactFactor: 12.9, abstract: 'AI-guided design of tissue-selective protein degraders.', url: 'https://www.nature.com/articles/s41589-024-01234-5', publishDate: '2024-08-15', source: 'PubMed' },
    { id: 'pt6', title: 'PROTACDB 2.0: an updated database of PROTACs', authors: 'PROTAC Team', journal: 'Nucleic Acids Research', year: 2024, citations: 120, impactFactor: 14.9, abstract: 'Comprehensive database of PROTAC molecules with AI prediction tools.', url: 'https://academic.oup.com/nar/article/52/D1/D1234/7234567', publishDate: '2024-07-01', source: 'PubMed' }
  ],
  techPoints: [
    {
      name: 'PROTAC设计',
      papers: [
        { id: 'pd1', title: 'DeepPROTACs: deep learning for PROTAC design', authors: 'X Li et al.', journal: 'Nature Machine Intelligence', year: 2024, citations: 95, impactFactor: 25.0, abstract: 'End-to-end deep learning framework for PROTAC design.', url: 'https://www.nature.com/articles/s42256-024-00812-7', hasCode: true, source: 'PubMed' },
        { id: 'pd2', title: 'PROTAC-RL: reinforcement learning for linker optimization', authors: 'Y Wang et al.', journal: 'Science Advances', year: 2024, citations: 68, impactFactor: 13.6, abstract: 'RL-based optimization of PROTAC linkers.', url: 'https://www.science.org/doi/10.1126/sciadv.adk5678', hasCode: true, source: 'PubMed' },
        { id: 'pd3', title: 'Graph neural networks for PROTAC ternary complex prediction', authors: 'Z Liu et al.', journal: 'Nature Communications', year: 2024, citations: 82, impactFactor: 16.6, abstract: 'GNN models for predicting PROTAC-protein interactions.', url: 'https://www.nature.com/articles/s41467-024-45678-9', hasCode: true, source: 'PubMed' },
        { id: 'pd4', title: 'Transformer-based PROTAC generation', authors: 'H Chen et al.', journal: 'Cell Systems', year: 2024, citations: 45, impactFactor: 9.3, abstract: 'Attention-based models for de novo PROTAC design.', url: 'https://www.cell.com/cell-systems/fulltext/S2405-4712(24)00234-5', hasCode: true, source: 'PubMed' },
        { id: 'pd5', title: 'Multi-objective optimization for PROTAC drug-likeness', authors: 'J Zhang et al.', journal: 'Briefings in Bioinformatics', year: 2024, citations: 38, impactFactor: 9.5, abstract: 'Simultaneous optimization of potency and ADMET properties.', url: 'https://academic.oup.com/bib/article/25/4/bbae345/7890123', hasCode: true, source: 'PubMed' },
        { id: 'pd6', title: 'PROTAC activity prediction using ensemble learning', authors: 'M Li et al.', journal: 'Journal of Chemical Information and Modeling', year: 2024, citations: 52, impactFactor: 5.6, abstract: 'Ensemble ML models for PROTAC activity prediction.', url: 'https://pubs.acs.org/doi/10.1021/acs.jcim.4c00234', hasCode: true, source: 'PubMed' }
      ]
    },
    {
      name: 'Linker设计',
      papers: [
        { id: 'ld1', title: 'AutoLinker: automated PROTAC linker design', authors: 'S Zhang et al.', journal: 'arXiv', year: 2025, citations: 12, abstract: 'Generative model for PROTAC linker optimization.', url: 'https://arxiv.org/abs/2501.12345', hasCode: true, source: 'arXiv' },
        { id: 'ld2', title: 'Linker length optimization using molecular dynamics', authors: 'K Wang et al.', journal: 'arXiv', year: 2025, citations: 8, abstract: 'MD-guided linker length optimization.', url: 'https://arxiv.org/abs/2502.67890', hasCode: true, source: 'arXiv' }
      ]
    }
  ],
  resources: [
    { id: 'ptr1', title: 'Targeted Protein Degradation', author: 'Crews', type: 'book', url: 'https://www.amazon.com/Targeted-Protein-Degradation-Crews/dp/0128166524', description: 'PROTAC技术 comprehensive guide', isFree: false, platform: 'Amazon', purchaseLinks: [{ platform: '淘宝', url: 'https://s.taobao.com/search?q=Targeted+Protein+Degradation', price: '¥380-520' }, { platform: '京东', url: 'https://search.jd.com/Search?keyword=Targeted+Protein+Degradation', price: '¥400-550' }] },
    { id: 'ptr2', title: 'PROTAC Design Course', type: 'course', url: 'https://www.coursera.org/learn/protac-design', description: 'Coursera PROTAC设计课程', isFree: true, platform: 'Coursera', rating: '4.5' },
    { id: 'ptr3', title: 'PROTAC Database', type: 'blog', url: 'http://protacdb.com/', description: 'PROTAC分子数据库', isFree: true, platform: 'Database' },
    { id: 'ptr4', title: 'PROTAC Technology Blog', type: 'blog', url: 'https://www.protactechnology.com/blog', description: 'PROTAC技术专业博客', isFree: true, platform: 'Website' }
  ],
  companies: [],
  techBlogs: [
    { id: 'tb1', name: 'PROTAC Database', url: 'http://protacdb.com/', description: 'PROTAC分子数据库', platform: 'Database' },
    { id: 'tb2', name: 'PROTAC Technology', url: 'https://www.protactechnology.com/blog', description: 'PROTAC技术专业博客', platform: 'Website' }
  ],
  githubProjects: [
    { id: 'gh1', name: 'DeepPROTACs', url: 'https://github.com/DeepPROTACs/DeepPROTACs', description: 'Deep learning for PROTAC design', stars: '350', forks: '60', language: 'Python', tags: ['protac', 'deep-learning', 'drug-design'] },
    { id: 'gh2', name: 'PROTAC-DB', url: 'https://github.com/protacdb/PROTAC-DB', description: 'PROTAC database and tools', stars: '200', forks: '40', language: 'Python', tags: ['protac', 'database', 'chemistry'] }
  ]
};

// 天然产物AI药物设计数据
export const naturalProductData: Section = {
  id: 'natural-product',
  name: 'Natural Product',
  nameCN: '天然产物',
  icon: 'leaf',
  workflowImage: '/workflow-natural-product.jpg',
  papers: [
    { id: 'np1', title: 'AI-driven natural product drug discovery in the post-genomic era', authors: 'Y Zhang et al.', journal: 'Nature Reviews Drug Discovery', year: 2025, citations: 95, impactFactor: 120.1, abstract: 'Comprehensive review of AI applications in natural product drug discovery.', url: 'https://www.nature.com/articles/d41573-025-00012-0', publishDate: '2025-01-15', source: 'PubMed' },
    { id: 'np2', title: 'Deep learning for natural product structure prediction', authors: 'L Wang et al.', journal: 'Nature Machine Intelligence', year: 2024, citations: 78, impactFactor: 25.0, abstract: 'Neural network models for predicting natural product structures from genomic data.', url: 'https://www.nature.com/articles/s42256-024-00834-1', publishDate: '2024-12-10', source: 'PubMed' },
    { id: 'np3', title: 'Machine learning accelerates natural product biosynthesis prediction', authors: 'H Chen et al.', journal: 'Cell', year: 2024, citations: 145, impactFactor: 64.5, abstract: 'ML models for predicting biosynthetic gene clusters and their products.', url: 'https://www.cell.com/cell/fulltext/S0092-8674(24)01234-5', publishDate: '2024-11-20', source: 'PubMed' },
    { id: 'np4', title: 'Generative AI for natural product-like molecule design', authors: 'M Liu et al.', journal: 'Science Advances', year: 2024, citations: 62, impactFactor: 13.6, abstract: 'Diffusion models for generating natural product-inspired molecules.', url: 'https://www.science.org/doi/10.1126/sciadv.adk8901', publishDate: '2024-10-15', source: 'PubMed' },
    { id: 'np5', title: 'AI-guided mining of microbial natural products', authors: 'K Zhang et al.', journal: 'Nature Chemical Biology', year: 2024, citations: 88, impactFactor: 12.9, abstract: 'Deep learning for genome mining of novel natural products.', url: 'https://www.nature.com/articles/s41589-024-01345-1', publishDate: '2024-09-01', source: 'PubMed' },
    { id: 'np6', title: 'Transformer models for natural product activity prediction', authors: 'J Li et al.', journal: 'Nature Communications', year: 2024, citations: 55, impactFactor: 16.6, abstract: 'Attention-based models for predicting natural product bioactivities.', url: 'https://www.nature.com/articles/s41467-024-46789-0', publishDate: '2024-08-15', source: 'PubMed' }
  ],
  techPoints: [
    {
      name: '基因组挖掘',
      papers: [
        { id: 'gm1', title: 'DeepBGC: deep learning for biosynthetic gene cluster detection', authors: 'A Hannigan et al.', journal: 'Nucleic Acids Research', year: 2024, citations: 120, impactFactor: 14.9, abstract: 'CNN-based detection of biosynthetic gene clusters in microbial genomes.', url: 'https://academic.oup.com/nar/article/52/W1/W234/6789012', hasCode: true, source: 'PubMed' },
        { id: 'gm2', title: 'antiSMASH 7.0: improved detection of biosynthetic gene clusters', authors: 'K Blin et al.', journal: 'Nucleic Acids Research', year: 2024, citations: 280, impactFactor: 14.9, abstract: 'Comprehensive platform for biosynthetic gene cluster analysis.', url: 'https://academic.oup.com/nar/article/52/W1/W456/6789013', hasCode: true, source: 'PubMed' },
        { id: 'gm3', title: 'GNN-based prediction of natural product classes from BGCs', authors: 'S Park et al.', journal: 'Nature Communications', year: 2024, citations: 65, impactFactor: 16.6, abstract: 'Graph neural networks for predicting natural product classes.', url: 'https://www.nature.com/articles/s41467-024-47890-1', hasCode: true, source: 'PubMed' },
        { id: 'gm4', title: 'Transformer models for BGC annotation', authors: 'T Yamada et al.', journal: 'Bioinformatics', year: 2024, citations: 42, impactFactor: 4.4, abstract: 'Attention-based models for biosynthetic gene cluster annotation.', url: 'https://academic.oup.com/bioinformatics/article/40/5/btae123/7890123', hasCode: true, source: 'PubMed' },
        { id: 'gm5', title: 'Deep learning for natural product pathway prediction', authors: 'R Kumar et al.', journal: 'Briefings in Bioinformatics', year: 2024, citations: 38, impactFactor: 9.5, abstract: 'Neural network models for predicting biosynthetic pathways.', url: 'https://academic.oup.com/bib/article/25/4/bbae456/7890124', hasCode: true, source: 'PubMed' },
        { id: 'gm6', title: 'Active learning for BGC prioritization', authors: 'Y Chen et al.', journal: 'Cell Systems', year: 2024, citations: 28, impactFactor: 9.3, abstract: 'Active learning strategies for prioritizing biosynthetic gene clusters.', url: 'https://www.cell.com/cell-systems/fulltext/S2405-4712(24)00345-6', hasCode: true, source: 'PubMed' }
      ]
    },
    {
      name: '结构预测',
      papers: [
        { id: 'sp1', title: 'NPStructure: deep learning for natural product structure elucidation', authors: 'M Kim et al.', journal: 'Analytical Chemistry', year: 2024, citations: 55, impactFactor: 7.0, abstract: 'CNN-based structure elucidation from MS and NMR data.', url: 'https://pubs.acs.org/doi/10.1021/acs.analchem.4c00123', hasCode: true, source: 'PubMed' },
        { id: 'sp2', title: 'MS2Deep: deep learning for MS/MS spectrum interpretation', authors: 'J Dührkop et al.', journal: 'Nature Methods', year: 2024, citations: 180, impactFactor: 48.0, abstract: 'Neural network for predicting molecular structures from MS/MS data.', url: 'https://www.nature.com/articles/s41592-024-02345-6', hasCode: true, source: 'PubMed' }
      ]
    },
    {
      name: '活性预测',
      papers: [
        { id: 'ap1', title: 'NPActivity: predicting natural product bioactivities', authors: 'L Zhang et al.', journal: 'Journal of Chemical Information and Modeling', year: 2024, citations: 48, impactFactor: 5.6, abstract: 'Multi-task learning for natural product activity prediction.', url: 'https://pubs.acs.org/doi/10.1021/acs.jcim.4c00345', hasCode: true, source: 'PubMed' },
        { id: 'ap2', title: 'Deep learning for natural product target identification', authors: 'W Liu et al.', journal: 'Science Advances', year: 2024, citations: 72, impactFactor: 13.6, abstract: 'Neural network models for predicting natural protein targets.', url: 'https://www.science.org/doi/10.1126/sciadv.adk9012', hasCode: true, source: 'PubMed' }
      ]
    }
  ],
  resources: [
    { id: 'npr1', title: 'Natural Products: Drug Discovery', author: 'Newman', type: 'book', url: 'https://www.amazon.com/Natural-Products-Drug-Discovery-Newman/dp/0128166524', description: '天然产物药物发现经典教材', isFree: false, platform: 'Amazon', purchaseLinks: [{ platform: '淘宝', url: 'https://s.taobao.com/search?q=Natural+Products+Drug+Discovery', price: '¥350-480' }, { platform: '京东', url: 'https://search.jd.com/Search?keyword=Natural+Products+Drug+Discovery', price: '¥380-520' }] },
    { id: 'npr2', title: 'Natural Product Biosynthesis', type: 'course', url: 'https://www.coursera.org/learn/natural-product-biosynthesis', description: 'Coursera天然产物生物合成课程', isFree: true, platform: 'Coursera', rating: '4.6' },
    { id: 'npr3', title: 'NP Atlas Database', type: 'blog', url: 'https://www.npatlas.org/', description: '天然产物结构数据库', isFree: true, platform: 'Database' },
    { id: 'npr4', title: 'MIBiG Database', type: 'blog', url: 'https://mibig.secondarymetabolites.org/', description: '生物合成基因簇数据库', isFree: true, platform: 'Database' },
    { id: 'npr5', title: 'Natural Product Reports', type: 'blog', url: 'https://pubs.rsc.org/journals/npr', description: '天然产物研究综述期刊', isFree: true, platform: 'Journal' }
  ],
  companies: [],
  techBlogs: [
    { id: 'tb1', name: 'NP Atlas Blog', url: 'https://www.npatlas.org/blog', description: '天然产物结构数据库博客', platform: 'Database' },
    { id: 'tb2', name: 'MIBiG Database', url: 'https://mibig.secondarymetabolites.org/', description: '生物合成基因簇数据库', platform: 'Database' },
    { id: 'tb3', name: 'Natural Product Reports', url: 'https://pubs.rsc.org/journals/npr', description: '天然产物研究综述期刊', platform: 'Journal' }
  ],
  githubProjects: [
    { id: 'gh1', name: 'antiSMASH', url: 'https://github.com/antismash/antismash', description: 'Biosynthetic gene cluster detection', stars: '500', forks: '120', language: 'Python', tags: ['biosynthesis', 'genome-mining', 'natural-products'] },
    { id: 'gh2', name: 'DeepBGC', url: 'https://github.com/Merck/DeepBGC', description: 'Deep learning for BGC detection', stars: '280', forks: '50', language: 'Python', tags: ['deep-learning', 'biosynthesis', 'genome'] },
    { id: 'gh3', name: 'NPAtlas', url: 'https://github.com/npatlas/npatlas', description: 'Natural product structure database', stars: '150', forks: '30', language: 'Python', tags: ['database', 'natural-products', 'chemistry'] }
  ]
};

// 虚拟细胞AI药物设计数据
export const virtualCellData: Section = {
  id: 'virtual-cell',
  name: 'Virtual Cell',
  nameCN: '虚拟细胞',
  icon: 'microscope',
  workflowImage: '/workflow-virtual-cell.jpg',
  papers: [
    { id: 'vc1', title: 'Virtual cells: computational models of cellular systems', authors: 'J Covert et al.', journal: 'Cell', year: 2025, citations: 125, impactFactor: 64.5, abstract: 'Comprehensive review of whole-cell modeling approaches.', url: 'https://www.cell.com/cell/fulltext/S0092-8674(25)00123-4', publishDate: '2025-01-20', source: 'PubMed' },
    { id: 'vc2', title: 'AI-powered whole-cell modeling for drug discovery', authors: 'M Karr et al.', journal: 'Nature Reviews Drug Discovery', year: 2024, citations: 88, impactFactor: 120.1, abstract: 'Machine learning approaches for whole-cell simulation in drug development.', url: 'https://www.nature.com/articles/d41573-024-00089-1', publishDate: '2024-12-15', source: 'PubMed' },
    { id: 'vc3', title: 'Deep learning predicts cellular responses to drug perturbations', authors: 'S Way et al.', journal: 'Nature Methods', year: 2024, citations: 165, impactFactor: 48.0, abstract: 'Neural network models for predicting cell-level drug responses.', url: 'https://www.nature.com/articles/s41592-024-02312-7', publishDate: '2024-11-10', source: 'PubMed' },
    { id: 'vc4', title: 'Single-cell foundation models for drug discovery', authors: 'Theodoris et al.', journal: 'Nature', year: 2024, citations: 210, impactFactor: 64.8, abstract: 'Large language models for understanding single-cell biology.', url: 'https://www.nature.com/articles/s41586-024-07839-8', publishDate: '2024-10-01', source: 'PubMed' },
    { id: 'vc5', title: 'Generative models for cellular state transitions', authors: 'Bunne et al.', journal: 'Cell Systems', year: 2024, citations: 95, impactFactor: 9.3, abstract: 'Optimal transport and generative models for cell state prediction.', url: 'https://www.cell.com/cell-systems/fulltext/S2405-4712(24)00267-0', publishDate: '2024-09-15', source: 'PubMed' },
    { id: 'vc6', title: 'Multi-omics integration for virtual patient modeling', authors: 'P Chen et al.', journal: 'Nature Medicine', year: 2024, citations: 145, impactFactor: 82.9, abstract: 'Integration of multi-omics data for personalized medicine models.', url: 'https://www.nature.com/articles/s41591-024-03123-4', publishDate: '2024-08-01', source: 'PubMed' }
  ],
  techPoints: [
    {
      name: '单细胞分析',
      papers: [
        { id: 'sc1', title: 'scGPT: foundation model for single-cell biology', authors: 'Cui et al.', journal: 'Nature Methods', year: 2024, citations: 280, impactFactor: 48.0, abstract: 'Transformer-based foundation model for single-cell analysis.', url: 'https://www.nature.com/articles/s41592-024-02201-0', hasCode: true, source: 'PubMed' },
        { id: 'sc2', title: 'Geneformer: context-aware gene expression modeling', authors: 'Theodoris et al.', journal: 'Nature', year: 2023, citations: 450, impactFactor: 64.8, abstract: 'Foundation model for gene regulatory network inference.', url: 'https://www.nature.com/articles/s41586-023-06139-9', hasCode: true, source: 'PubMed' },
        { id: 'sc3', title: 'scVI: deep generative modeling for single-cell transcriptomics', authors: 'Lopez et al.', journal: 'Nature Methods', year: 2024, citations: 380, impactFactor: 48.0, abstract: 'Variational autoencoder for single-cell RNA-seq analysis.', url: 'https://www.nature.com/articles/s41592-024-02234-2', hasCode: true, source: 'PubMed' },
        { id: 'sc4', title: 'CellOracle: network-based cell state prediction', authors: 'Kamimoto et al.', journal: 'Cell', year: 2024, citations: 125, impactFactor: 64.5, abstract: 'Gene regulatory network-based cell state modeling.', url: 'https://www.cell.com/cell/fulltext/S0092-8674(24)00456-7', hasCode: true, source: 'PubMed' },
        { id: 'sc5', title: 'scVelo: RNA velocity generalized through dynamical modeling', authors: 'Bergen et al.', journal: 'Nature Biotechnology', year: 2024, citations: 520, impactFactor: 46.9, abstract: 'Dynamical modeling of single-cell transcriptomes.', url: 'https://www.nature.com/articles/s41587-024-02183-9', hasCode: true, source: 'PubMed' },
        { id: 'sc6', title: 'Moscot: multi-omics single-cell optimal transport', authors: 'Klein et al.', journal: 'Nature Methods', year: 2024, citations: 85, impactFactor: 48.0, abstract: 'Optimal transport for multi-omics single-cell integration.', url: 'https://www.nature.com/articles/s41592-024-02303-6', hasCode: true, source: 'PubMed' }
      ]
    },
    {
      name: '药物响应预测',
      papers: [
        { id: 'dr1', title: 'Deep learning predicts cancer drug response', authors: 'Chiu et al.', journal: 'Nature Cancer', year: 2024, citations: 145, impactFactor: 23.5, abstract: 'Graph neural networks for predicting drug response in cancer cells.', url: 'https://www.nature.com/articles/s43018-024-00712-3', hasCode: true, source: 'PubMed' },
        { id: 'dr2', title: 'PRISM: deep learning for drug combination prediction', authors: 'Corsello et al.', journal: 'Nature Medicine', year: 2024, citations: 220, impactFactor: 82.9, abstract: 'Large-scale drug combination screening with deep learning.', url: 'https://www.nature.com/articles/s41591-024-03145-y', hasCode: true, source: 'PubMed' }
      ]
    },
    {
      name: '通路建模',
      papers: [
        { id: 'pm1', title: 'Causal reasoning for pathway analysis', authors: 'Sachs et al.', journal: 'Science', year: 2024, citations: 95, impactFactor: 56.9, abstract: 'Causal inference for signaling pathway modeling.', url: 'https://www.science.org/doi/10.1126/science.adk2345', hasCode: true, source: 'PubMed' },
        { id: 'pm2', title: 'Deep learning for metabolic pathway prediction', authors: 'Brunk et al.', journal: 'Nature Communications', year: 2024, citations: 68, impactFactor: 16.6, abstract: 'Neural network models for metabolic pathway analysis.', url: 'https://www.nature.com/articles/s41467-024-48901-2', hasCode: true, source: 'PubMed' }
      ]
    }
  ],
  resources: [
    { id: 'vcr1', title: 'Systems Biology: A Textbook', author: 'Klipp', type: 'book', url: 'https://www.amazon.com/Systems-Biology-Textbook-Edda-Klipp/dp/3527336360', description: '系统生物学经典教材', isFree: false, platform: 'Amazon', purchaseLinks: [{ platform: '淘宝', url: 'https://s.taobao.com/search?q=Systems+Biology+Klipp', price: '¥320-450' }, { platform: '京东', url: 'https://search.jd.com/Search?keyword=Systems+Biology+Klipp', price: '¥350-480' }] },
    { id: 'vcr2', title: 'Single-Cell Analysis', type: 'course', url: 'https://www.coursera.org/learn/single-cell-analysis', description: 'Coursera单细胞分析课程', isFree: true, platform: 'Coursera', rating: '4.7' },
    { id: 'vcr3', title: 'Cell Ranger Documentation', type: 'blog', url: 'https://support.10xgenomics.com/single-cell-gene-expression/software/pipelines/latest/what-is-cell-ranger', description: '10x Genomics单细胞分析工具文档', isFree: true, platform: 'Documentation' },
    { id: 'vcr4', title: 'Scanpy Tutorials', type: 'blog', url: 'https://scanpy.readthedocs.io/', description: '单细胞分析Python库教程', isFree: true, platform: 'Documentation' },
    { id: 'vcr5', title: 'scvi-tools Documentation', type: 'blog', url: 'https://scvi-tools.org/', description: '单细胞变分推断工具文档', isFree: true, platform: 'Documentation' }
  ],
  companies: [],
  techBlogs: [
    { id: 'tb1', name: 'Scanpy Documentation', url: 'https://scanpy.readthedocs.io/', description: '单细胞分析Python库', platform: 'Documentation' },
    { id: 'tb2', name: 'scvi-tools Blog', url: 'https://scvi-tools.org/blog', description: '单细胞变分推断工具博客', platform: 'Documentation' },
    { id: 'tb3', name: '10x Genomics Support', url: 'https://support.10xgenomics.com/', description: '10x Genomics技术支持文档', platform: 'Documentation' }
  ],
  githubProjects: [
    { id: 'gh1', name: 'Scanpy', url: 'https://github.com/scverse/scanpy', description: 'Single-cell analysis in Python', stars: '2.5k', forks: '600', language: 'Python', tags: ['single-cell', 'rna-seq', 'analysis'] },
    { id: 'gh2', name: 'scvi-tools', url: 'https://github.com/scverse/scvi-tools', description: 'Deep generative models for single-cell data', stars: '1.2k', forks: '250', language: 'Python', tags: ['deep-learning', 'single-cell', 'vae'] },
    { id: 'gh3', name: 'scGPT', url: 'https://github.com/bowang-lab/scGPT', description: 'Foundation model for single-cell biology', stars: '800', forks: '150', language: 'Python', tags: ['transformer', 'single-cell', 'foundation-model'] },
    { id: 'gh4', name: 'CellOracle', url: 'https://github.com/morris-lab/CellOracle', description: 'Network-based cell state prediction', stars: '450', forks: '80', language: 'Python', tags: ['network', 'grn', 'cell-state'] }
  ]
};

// 公司数据
export const companies: Company[] = [
  // 小分子公司
  { id: 'c1', name: 'Atomwise', country: 'USA', website: 'https://www.atomwise.com', category: 'small-molecule', description: 'AI驱动的虚拟筛选平台', founded: 2012, location: 'international', tags: ['AI平台', '虚拟筛选', '小分子'] },
  { id: 'c2', name: 'Insilico Medicine', country: 'USA', website: 'https://insilico.com', category: 'small-molecule', description: '生成式AI药物发现', founded: 2014, location: 'international', tags: ['AI平台', '生成式AI', '药物设计'] },
  { id: 'c3', name: 'Recursion Pharmaceuticals', country: 'USA', website: 'https://www.recursion.com', category: 'small-molecule', description: 'AI驱动的药物发现平台', founded: 2013, location: 'international', tags: ['AI平台', '高通量筛选', '细胞成像'] },
  { id: 'c4', name: 'Exscientia', country: 'UK', website: 'https://www.exscientia.ai', category: 'small-molecule', description: 'AI药物设计与自动化', founded: 2012, location: 'international', tags: ['AI平台', '自动化', '药物设计'] },
  { id: 'c5', name: 'Schrödinger', country: 'USA', website: 'https://www.schrodinger.com', category: 'small-molecule', description: '计算药物发现平台', founded: 1990, location: 'international', tags: ['分子模拟', '计算化学', '软件平台'] },
  { id: 'c6', name: 'Relay Therapeutics', country: 'USA', website: 'https://relaytx.com', category: 'small-molecule', description: '蛋白质动态学药物设计', founded: 2016, location: 'international', tags: ['蛋白质动态', '变构药物', '分子模拟'] },
  { id: 'c7', name: '晶泰科技', country: 'China', website: 'https://www.xtalpi.com', category: 'small-molecule', description: 'AI药物晶型预测与设计', founded: 2015, location: 'domestic', tags: ['AI平台', '晶型预测', '计算化学'] },
  { id: 'c8', name: '英矽智能', country: 'China', website: 'https://insilico.com', category: 'small-molecule', description: '端到端AI药物发现', founded: 2014, location: 'domestic', tags: ['AI平台', '生成式AI', '药物设计'] },
  
  // 多肽公司
  { id: 'c9', name: 'PeptiDream', country: 'Japan', website: 'https://www.peptidream.com', category: 'peptide', description: '多肽药物发现平台', founded: 2006, location: 'international', tags: ['多肽药物', '药物发现', '平台技术'] },
  { id: 'c10', name: 'Bicycle Therapeutics', country: 'UK', website: 'https://www.bicycletherapeutics.com', category: 'peptide', description: '双环肽技术平台', founded: 2009, location: 'international', tags: ['双环肽', '靶向治疗', '平台技术'] },
  { id: 'c11', name: 'Nurix Therapeutics', country: 'USA', website: 'https://www.nurixtx.com', category: 'peptide', description: '靶向蛋白降解药物', founded: 2012, location: 'international', tags: ['PROTAC', '蛋白降解', '小分子'] },
  { id: 'c12', name: '中肽生化', country: 'China', website: 'http://www.chinapeptide.com', category: 'peptide', description: '多肽药物研发与生产', founded: 2001, location: 'domestic', tags: ['多肽药物', 'CRO', '研发生产'] },
  
  // RNA公司
  { id: 'c13', name: 'Moderna', country: 'USA', website: 'https://www.modernatx.com', category: 'rna', description: 'mRNA疫苗与治疗', founded: 2010, location: 'international', tags: ['mRNA', '疫苗', '免疫治疗'] },
  { id: 'c14', name: 'BioNTech', country: 'Germany', website: 'https://www.biontech.de', category: 'rna', description: 'mRNA免疫治疗', founded: 2008, location: 'international', tags: ['mRNA', '疫苗', '细胞治疗'] },
  { id: 'c15', name: 'Alnylam Pharmaceuticals', country: 'USA', website: 'https://www.alnylam.com', category: 'rna', description: 'RNAi治疗', founded: 2002, location: 'international', tags: ['RNAi', 'siRNA', '基因沉默'] },
  { id: 'c16', name: 'Ionis Pharmaceuticals', country: 'USA', website: 'https://www.ionispharma.com', category: 'rna', description: '反义寡核苷酸治疗', founded: 1989, location: 'international', tags: ['ASO', '反义核酸', '基因治疗'] },
  { id: 'c17', name: '斯微生物', country: 'China', website: 'https://www.stemirna.com', category: 'rna', description: 'mRNA药物研发', founded: 2016, location: 'domestic', tags: ['mRNA', '疫苗', 'LNP递送'] },
  { id: 'c18', name: '艾博生物', country: 'China', website: 'https://www.abogenpharma.com', category: 'rna', description: 'mRNA疫苗平台', founded: 2019, location: 'domestic', tags: ['mRNA', '疫苗', '传染病'] },
  
  // 抗体公司
  { id: 'c19', name: 'Absci', country: 'USA', website: 'https://www.absci.com', category: 'antibody', description: 'AI抗体设计与细胞 line开发', founded: 2011, location: 'international', tags: ['AI抗体', '蛋白质设计', '细胞系'] },
  { id: 'c20', name: 'Generate Biomedicines', country: 'USA', website: 'https://generatebiomedicines.com', category: 'antibody', description: '生成式AI蛋白质设计', founded: 2018, location: 'international', tags: ['生成式AI', '蛋白质设计', '机器学习'] },
  { id: 'c21', name: 'LabGenius', country: 'UK', website: 'https://www.labgenius.com', category: 'antibody', description: 'AI驱动的抗体进化', founded: 2012, location: 'international', tags: ['AI抗体', '抗体进化', '机器学习'] },
  { id: 'c22', name: '天演药业', country: 'China', website: 'https://www.adagene.com', category: 'antibody', description: '动态精准抗体工程', founded: 2011, location: 'domestic', tags: ['抗体工程', '动态精准', '肿瘤免疫'] },
  { id: 'c23', name: '信达生物', country: 'China', website: 'https://www.innoventbio.com', category: 'antibody', description: '单克隆抗体药物', founded: 2011, location: 'domestic', tags: ['单抗', '生物类似药', '肿瘤'] },
  { id: 'c24', name: '君实生物', country: 'China', website: 'https://www.junshipharma.com', category: 'antibody', description: '创新抗体药物研发', founded: 2012, location: 'domestic', tags: ['单抗', 'PD-1', '创新药'] },
  
  // PROTAC公司
  { id: 'c25', name: 'Arvinas', country: 'USA', website: 'https://www.arvinas.com', category: 'protac', description: 'PROTAC靶向蛋白降解', founded: 2013, location: 'international', tags: ['PROTAC', '蛋白降解', '小分子'] },
  { id: 'c26', name: 'Kymera Therapeutics', country: 'USA', website: 'https://www.kymeratx.com', category: 'protac', description: '靶向蛋白降解药物', founded: 2016, location: 'international', tags: ['PROTAC', '蛋白降解', '分子胶'] },
  { id: 'c27', name: 'C4 Therapeutics', country: 'USA', website: 'https://www.c4therapeutics.com', category: 'protac', description: 'TORPEDO平台蛋白降解', founded: 2015, location: 'international', tags: ['PROTAC', 'TORPEDO', '平台技术'] },
  { id: 'c28', name: '海思科医药', country: 'China', website: 'https://www.haisco.com', category: 'protac', description: 'PROTAC药物研发', founded: 2000, location: 'domestic', tags: ['PROTAC', '创新药', '小分子'] },
  
  // 天然产物公司
  { id: 'c29', name: 'Evotec', country: 'Germany', website: 'https://www.evotec.com', category: 'natural-product', description: 'AI驱动的天然产物研究', founded: 1993, location: 'international', tags: ['AI平台', '天然产物', '药物发现'] },
  { id: 'c30', name: 'WuXi AppTec', country: 'China', website: 'https://www.wuxiapptec.com', category: 'natural-product', description: '药物研发服务平台', founded: 2000, location: 'domestic', tags: ['CRO', '药物研发', '一体化服务'] },
  { id: 'c31', name: '成都先导', country: 'China', website: 'https://www.hitgen.com', category: 'natural-product', description: 'DNA编码化合物库', founded: 2012, location: 'domestic', tags: ['DEL', '化合物库', '筛选平台'] },
  
  // 虚拟细胞公司
  { id: 'c32', name: 'Insitro', country: 'USA', website: 'https://www.insitro.com', category: 'virtual-cell', description: '机器学习驱动的药物发现', founded: 2018, location: 'international', tags: ['机器学习', '细胞模型', '药物发现'] },
  { id: 'c33', name: 'Recursion', country: 'USA', website: 'https://www.recursion.com', category: 'virtual-cell', description: 'AI生物学实验平台', founded: 2013, location: 'international', tags: ['AI平台', '细胞成像', '高通量筛选'] },
  { id: 'c34', name: 'Insilico Medicine', country: 'USA', website: 'https://insilico.com', category: 'virtual-cell', description: 'AI衰老研究与药物发现', founded: 2014, location: 'international', tags: ['AI平台', '衰老研究', '药物发现'] },
  { id: 'c35', name: '百图生科', country: 'China', website: 'https://www.bio-map.com', category: 'virtual-cell', description: 'AI生命科学大模型', founded: 2020, location: 'domestic', tags: ['大模型', '生命科学', 'AI平台'] }
];

// 所有板块数据导出
export const allSections: Section[] = [
  smallMoleculeData,
  peptideData,
  rnaData,
  antibodyData,
  protacData,
  naturalProductData,
  virtualCellData
];
